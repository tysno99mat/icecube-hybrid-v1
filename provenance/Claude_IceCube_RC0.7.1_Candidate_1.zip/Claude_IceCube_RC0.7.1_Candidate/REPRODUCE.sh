#!/bin/sh
# One-command offline replay of the RC0.7.1 regression suite.
# Needs: Node.js ≥ 20 (tested on v22.22.0). No network: three@0.160.0 is vendored and checked against package-lock integrity.
set -e
cd "$(dirname "$0")"
if [ ! -f node_modules/three/build/three.module.js ]; then
  node -e "const c=require('crypto'),f=require('fs');const want=JSON.parse(f.readFileSync('package-lock.json')).packages['node_modules/three'].integrity;const got='sha512-'+c.createHash('sha512').update(f.readFileSync('vendor/three-0.160.0.tgz')).digest('base64');if(want!==got){console.error('three tarball integrity mismatch');process.exit(1)}console.log('three tarball integrity OK')"
  mkdir -p node_modules/three && tar -xzf vendor/three-0.160.0.tgz -C node_modules/three --strip-components=1
fi
(sha256sum -c SHA256SUMS.txt --quiet 2>/dev/null || shasum -a 256 -c SHA256SUMS.txt --quiet) && echo "SHA256 manifest OK"
node tests/run_all.mjs
node tests/compare_frozen.mjs
# Rebuilding the app (optional) additionally needs esbuild: npm ci && node build/build.mjs
