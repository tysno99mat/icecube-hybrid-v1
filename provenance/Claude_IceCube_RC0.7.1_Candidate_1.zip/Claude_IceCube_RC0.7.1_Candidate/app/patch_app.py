"""Patch the RC0.5 app (app/rc05_original.html) into the RC0.6 template.
The physics block is removed and replaced by the shared core (inlined at build time).
Every edit is an exact single-match replacement; the script aborts otherwise."""
import pathlib, re
ROOT = pathlib.Path(__file__).parent
src = (ROOT / "rc05_original.html").read_text()

def rep(s, old, new, label):
    n = s.count(old); assert n == 1, f"{label}: {n} matches"; return s.replace(old, new)

# 1. physics block -> core + adapter
m = re.search(r"/\* ---------- physics constants ---------- \*/.*?(?=/\* ---------- renderer & scene ---------- \*/)", src, re.S)
ADAPTER = r"""/*__CORE__*/
/* ---------- app bindings to the shared RC0.6 core ---------- */
const C = K.C, BEDROCK = K.BEDROCK, inIce = K.inIce, doms = K.doms, strings = K.strings;
const IDX = K.indices(); const COS_TC = IDX.COS_TC, SIN_TC = IDX.SIN_TC, N_GROUP = IDX.N_GROUP, V_LIGHT = IDX.V_LIGHT;
const NS_PER_SEC = 500;
const V3a = a => new THREE.Vector3(a[0], a[1], a[2]);
const ZH_REASONS = [
  [/^N=(\d+) < (\d+)/, (m)=>`命中 ${m[1]} 顆，少於 ${m[2]} 顆`],
  [/^non-finite hit values/, ()=>'命中資料含非有限值'],
  [/^time variance/, ()=>'命中時間沒有分散（幾乎同時）'],
  [/^degenerate velocity/, ()=>'擬合結果退化'],
  [/^strings=(\d+) < (\d+)/, (m)=>`只涵蓋 ${m[1]} 條纜線（至少要 ${m[2]} 條）`],
  [/^time span ([\d.]+) ns < (\d+)/, (m)=>`時間跨度 ${m[1]} ns，少於 ${m[2]} ns`],
  [/^hit cloud is not 3-D \(third axis ([\d.]+) m/, (m)=>`命中點幾乎落在同一平面或直線上（第三軸 ${m[1]} m）`],
];
const zhReason = r => { for(const [re,f] of ZH_REASONS){ const m=r.match(re); if(m) return f(m); } return r; };
function toAppEvent(res){
  const e = res.event, inp = res.input;
  const ev = { type:inp.type, E:inp.energy, dir:V3a(inp.direction), seed:inp.seed, ledger:res.ledger,
    tracks: e.tracks.map(t => ({ p0:V3a(t.p0), s0:t.s0, s1:t.s1, sMax:t.sMax, E:t.E0, stopped:t.stopped })),
    points: e.points.map(p => ({ pos:V3a(p.pos), t:p.t, E:p.E, main:p.origin!=='stochastic' })),
    vertex: e.vertex ? V3a(e.vertex) : null, nuEnd:V3a(e.nuEnd), center:V3a(e.center), Emu:e.Emu, Ehad:e.Ehad,
    hits:res.hits, byDom:res.byDom, clean:res.clean };
  ev.phys = res.hits.filter(h => !h.noise && h.clean).sort((a,b) => a.t-b.t);
  const ts = ev.phys.map(h => h.t);
  ev.cMin = ts.length ? ts[0] : 0;
  ev.cMax = ts.length ? ts[Math.floor((ts.length-1)*0.9)] : 1;
  if(ev.cMax-ev.cMin<50) ev.cMax = ev.cMin+50;
  ev.lastHit = ts.length ? ts[ts.length-1] : 0;
  ev.tStart = ev.type==='through' ? (ts.length ? ts[0]-700 : 0) : -900;
  ev.tEnd = (ts.length ? ev.lastHit : 1500) + 400;
  const r = res.reco;
  ev.reco = { ...r, qa:res.qa, dirV: r.fitDirection ? V3a(r.fitDirection) : null, posV: r.fitPosition ? V3a(r.fitPosition) : null, cogV: r.vertexEstimate ? V3a(r.vertexEstimate) : null };
  return ev;
}

"""
src = src[:m.start()] + ADAPTER + src[m.end():]

# 2. reconstruction visuals (status-aware; topology decided by data, not by the true event type)
src = rep(src, """  if(ev.reco){
    const R=ev.reco; const isCasc = ev.type==='cascade';
    const c = isCasc? R.cog : R.pos;
    const a=c.clone().addScaledVector(R.dir,-(isCasc?400:1500)), b=c.clone().addScaledVector(R.dir,isCasc?400:1500);
    V.reco = lineBetween(a,b,new THREE.LineDashedMaterial({color:0x36e2c3,dashSize:30,gapSize:16,transparent:true,opacity:0.95}));
    const arrow=new THREE.Mesh(new THREE.ConeGeometry(18,60,16), new THREE.MeshBasicMaterial({color:0x36e2c3}));
    arrow.position.copy(b); arrow.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),R.dir); V.reco.add(arrow);
    if(isCasc){ const cm=new THREE.Mesh(new THREE.OctahedronGeometry(16), new THREE.MeshBasicMaterial({color:0x36e2c3,wireframe:true})); cm.position.copy(R.cog); V.reco.add(cm); }
    evGroup.add(V.reco);
  }""", """  const R=ev.reco;
  // RC0.7: a LineFit line is drawn the same way whatever its internal status — colour never encodes reliability.
  if(R && R.dirV){
    const a=R.posV.clone().addScaledVector(R.dirV,-1200), b=R.posV.clone().addScaledVector(R.dirV,1200);
    V.reco = lineBetween(a,b,new THREE.LineDashedMaterial({color:0x36e2c3,dashSize:22,gapSize:20,transparent:true,opacity:0.8}));
    const arrow=new THREE.Mesh(new THREE.ConeGeometry(18,60,16), new THREE.MeshBasicMaterial({color:0x36e2c3,transparent:true,opacity:0.8}));
    arrow.position.copy(b); arrow.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),R.dirV); V.reco.add(arrow);
    evGroup.add(V.reco);
  }
  if(R && R.vertexStatus==='CHARGE_CENTROID_ILLUSTRATIVE' && !R.dirV){ const cm=new THREE.Mesh(new THREE.OctahedronGeometry(16), new THREE.MeshBasicMaterial({color:0x36e2c3,wireframe:true})); cm.position.copy(R.cogV); V.cog=cm; evGroup.add(cm); }""", "reco visuals")
src = rep(src, "  if(V.reco){ V.reco.visible=$('tgReco').checked && done; }", "  if(V.reco){ V.reco.visible=$('tgReco').checked && done; }\n  if(V.cog){ V.cog.visible=$('tgReco').checked && done; }", "cog visibility")

# 3. step-5 narrative
src = rep(src, """  if(s===4 && ev.reco){
    txt += ev.type==='cascade' ? `　頂點誤差 ${ev.reco.vErr.toFixed(0)} m，方向誤差 ${ev.reco.ang.toFixed(0)}°。` : `　LineFit 方向誤差 ${ev.reco.ang.toFixed(1)}°。`;
  }""", """  if(s===4 && ev.reco){
    const R=ev.reco, qa=R.qa;
    if(R.directionStatus==='NOT_IDENTIFIABLE_IN_PEDAGOGICAL_CASCADE_MODEL') txt += (qa.vertexError_m!=null ? `　電荷重心離模擬真值頂點 ${qa.vertexError_m.toFixed(0)} m（模擬 QA）。` : '');
    else if(R.fitDirection) txt += `　模擬 QA：候選徑跡與模擬真值方向差 ${qa.angularError_deg.toFixed(1)}°${qa.hemisphereFlip?'，翻到了另一個半球':''}。`;
    else txt += `　LineFit 無法計算：${zhReason(R.reasons[0])}。`;
  }""", "step text")
src = rep(src, "'光幾乎對稱，方向很難由時間判斷，但總電荷能較準地估計能量。'", "'光幾乎對稱，時間序列幾乎不含方向資訊；電荷重心可估計頂點位置。本模型的光量未校準，不能用來反推真實能量。'", "cascade step")

# 4. readouts
src = rep(src, "const fmtE = e => e>=1000 ? `${(e/1000).toFixed(e>=10000?0:1)} PeV` : `${e>=10?e.toFixed(0):e.toFixed(1)} TeV`;",
          "const fmtE = e => e>=1000 ? `${(e/1000).toFixed(e>=10000?0:1)} PeV` : (e>=1 ? `${e>=10?e.toFixed(0):e.toFixed(1)} TeV` : `${(e*1000).toFixed(0)} GeV`);", "fmtE")
src = rep(src, """  if(ev.type==='through') eTxt = `μ 子 ${fmtE(ev.Emu)}<small>微中子能量更高，只看得到 μ 子</small>`;
  else if(ev.type==='starting') eTxt = `${fmtE(ev.E)}<small>簇射 ${fmtE(ev.Ehad)}＋μ 子 ${fmtE(ev.Emu)}</small>`;
  else eTxt = `${fmtE(ev.E)}<small>幾乎全部沉積在冰中</small>`;""", """  const L=ev.ledger, stop=ev.tracks[0]?.stopped;
  if(ev.type==='through') eTxt = `μ 子 ${fmtE(ev.Emu)}<small>進入模擬段時的能量；沿途沉積 ${fmtE(L.totalDepositedEnergy)}，${stop?'μ 子在段內停止':'帶出 '+fmtE(L.escapedEnergy)}</small>`;
  else if(ev.type==='starting') eTxt = `${fmtE(ev.E)}<small>簇射 ${fmtE(ev.Ehad)}＋μ 子 ${fmtE(ev.Emu)}；共沉積 ${fmtE(L.totalDepositedEnergy)}</small>`;
  else eTxt = `${fmtE(ev.E)}<small>全部沉積在作用點</small>`;""", "energy readout")
src = rep(src, "  $('stPE').textContent = `${pe>=1000?Math.round(pe).toLocaleString():pe.toFixed(0)} PE`;",
          "  $('stPE').innerHTML = `${pe>=1000?Math.round(pe).toLocaleString():pe.toFixed(0)} model PE<small>相對光量，未校準</small>`;", "PE readout")
src = rep(src, """  if(!ev.reco){ $('stReco').textContent='命中太少，無法擬合'; $('recoNote').textContent=''; }
  else if(ev.type==='cascade'){
    $('stReco').innerHTML = `頂點誤差 ${ev.reco.vErr.toFixed(0)} m<small>方向誤差 ${ev.reco.ang.toFixed(0)}°</small>`;
    $('recoNote').textContent = '級聯的光近似球形，時間序列幾乎不含方向資訊，所以 LineFit 方向常常偏很多；電荷重心可以找到頂點的大致位置。';
  } else {
    $('stReco').innerHTML = `誤差 ${ev.reco.ang.toFixed(1)}°<small>LineFit 速度 ${ev.reco.speed.toFixed(2)} m/ns（真實 0.30）</small>`;
    $('recoNote').textContent = 'LineFit 把每顆 DOM 的位置對到達時間做線性擬合。散射讓遠處的光晚到，擬合速度會低於光速；正式分析改用似然法與冰模型修正這些延遲。';
  }""", """  { const R=ev.reco, qa=R.qa; let note='';
    if(R.directionStatus==='NOT_IDENTIFIABLE_IN_PEDAGOGICAL_CASCADE_MODEL'){
      $('stReco').innerHTML = `方向無法識別<small>NOT IDENTIFIABLE IN THIS PEDAGOGICAL CASCADE MODEL</small>`;
      note = '級聯的光在本模型中是等向的：把模擬真值方向反過來，命中結果完全相同，所以任何方向估計都沒有意義。可以看的是頂點位置與光量分布。';
      if(qa.vertexError_m!=null) note += `電荷重心離模擬真值頂點 ${qa.vertexError_m.toFixed(0)} m（模擬 QA）。`;
    } else if(R.fitDirection){
      const tier={FIT_COMPUTED:'LineFit 已計算',GEOMETRY_NONDEGENERATE:'LineFit 已計算（命中幾何非退化）',FIT_RENDERABLE:'LineFit 示意'}[R.fitStatus];
      $('stReco').innerHTML = `${tier}<small>模擬 QA：與模擬真值方向差 ${qa.angularError_deg.toFixed(1)}°${qa.hemisphereFlip?'（翻到另一半球）':''}；擬合斜率 ${R.fitSpeed.toFixed(2)} m/ns</small>`;
      note = 'LineFit 是簡化的初步重建，只作示意；通過內部檢查並不代表方向正確，它可能失敗甚至翻轉。擬合斜率是回歸參數，不是 μ 子或光子的速度，也可能大於光速（0.30 m/ns）。與模擬真值的比較只在模擬 QA 中才有。';
      if(R.reasons.length) note += `另外：${R.reasons.map(zhReason).join('；')}。`;
    } else {
      $('stReco').innerHTML = `LineFit 無法計算<small>${R.reasons[0]?zhReason(R.reasons[0]):''}</small>`;
    }
    $('recoNote').textContent = note; }""", "reco readout")
src = rep(src, "${h.q.toFixed(1)} PE${h.noise?", "${h.q.toFixed(1)} model PE${h.noise?", "tooltip PE")

# 5. new event via contract
src = rep(src, "  ev = makeEvent(curType, eFromSlider(), $('dirSel').value, seed ?? (1+Math.floor(Math.random()*99999)));",
          """  const inp = K.sampleEventInput(curType, eFromSlider(), $('dirSel').value, seed ?? (1+Math.floor(Math.random()*99999)));
  const res = K.simulateEvent(inp);
  if(res.status!=='OK'){ $('evName').textContent = '輸入不合法：'+res.errors.join('；'); return; }
  ev = toAppEvent(res);""", "newEvent")

# 6. badge + model notes
src = rep(src, ".brand p{margin:6px 0 0;color:var(--fg);font-size:13.5px}",
          ".brand p{margin:6px 0 0;color:var(--fg);font-size:13.5px}\n.badge{align-self:flex-start;margin-top:8px!important;font:600 10.5px var(--f-mono)!important;letter-spacing:.08em;color:var(--muted)!important;border:1px solid var(--line);border-radius:4px;padding:2px 6px}", "badge css")
src = rep(src, "      <h1>冰立方 IceCube<small>2026 諾貝爾物理獎・南極冰下的微中子望遠鏡</small></h1>",
          "      <h1>冰立方 IceCube<small>2026 諾貝爾物理獎・南極冰下的微中子望遠鏡</small></h1>\n      <p class=\"badge\">UNCALIBRATED TEACHING MODEL · RC0.7.1 候選</p>", "badge")
m2 = re.search(r"        <h3>依 IceCube 公開規格</h3>.*?(?=        <h3>參考</h3>)", src, re.S)
NOTES = """        <h3>依 IceCube 公開規格</h3>
        <ul>
          <li>86 條纜線 × 60 顆 DOM ＝ 5160 顆；標準纜線 DOM 位於 1450–2450 m，間距約 17 m。</li>
          <li>纜線水平間距約 125 m，六角形排列，涵蓋約 1 km³ 冰。</li>
          <li>DeepCore 8 條纜線集中在中心：10 顆在塵埃層上方做否決層，50 顆密集排在 2100–2450 m 最清澈的冰中。</li>
          <li>冰厚約 2820 m；約 2000 m 附近有一層塵埃，吸收與散射明顯較強。</li>
          <li>切倫科夫角 cos θ = 1/n；本模型用相位折射率 1.32、群折射率 1.35 的有效近似。</li>
          <li>LineFit（位置對時間的線性擬合）是 IceCube 實際用過的初步方向估計方法。</li>
        </ul>
        <h3>這個模型怎麼算（RC0.6）</h3>
        <ul>
          <li>μ 子有能量帳本：每一段連續損失與每一次隨機能損都從剩餘能量扣除，總沉積不會超過初始能量；能量用完 μ 子就停止。</li>
          <li>光有三個來源：μ 子本身的切倫科夫光、連續損失沿徑跡放出的光、每次隨機能損與簇射的點光源。每一份沉積能量只算一次。</li>
          <li>每個光源各自抽光子數；DOM 的時間取所有光源中最早到的光子，所以把同一個光源拆成很多小份，結果不會改變。</li>
          <li>冰的衰減沿光的路徑逐層精確積分，斜穿塵埃層時不會被漏掉。</li>
          <li>LineFit 只作示意：它是簡化的初步重建，可能失敗甚至翻轉方向；內部檢查通過也不代表方向正確。</li>
          <li>級聯事件的光是等向的，命中不含方向資訊，所以本模型不輸出級聯方向。</li>
        </ul>
        <h3>簡化與示意</h3>
        <ul>
          <li>光量單位是 model PE，只代表相對亮度，沒有和 IceCube 校準過。</li>
          <li>纜線位置是 125 m 六角格的近似排列，不是真實座標；DeepCore 位置與 DOM 深度間距同樣是近似。</li>
          <li>DOM（實際直徑約 33 cm）、IceTop 冰槽與 IceCube Lab 都放大顯示；DOM 不分入射方向。</li>
          <li>散射延遲：WEIBULL FIRST-PHOTON TEACHING MODEL — UNCALIBRATED。平均值沿用 0.8 ns/m ÷ n^0.7，但變異約只有原本指數分布的一半、長尾也輕很多，所以散射物理並沒有被保留。各冰層衰減長度是示意值。</li>
          <li>暗計數雜訊以每顆 DOM 約 500 Hz 估算；時間戳另加 2 ns 電子抖動，所以「量到的時間」偶爾會比直達光早一點，但光子本身不會。</li>
        </ul>
"""
src = src[:m2.start()] + NOTES + src[m2.end():]
src = rep(src, '<label for="eSl">能量 <output id="eOut">80 TeV</output></label>', '<label for="eSl">能量（穿越：μ 子；其他：微中子） <output id="eOut">80 TeV</output></label>', "energy label")
src = rep(src, "'有徑跡可抓方向，又有起點可估能量：起始徑跡兼具兩者優點。'", "'有徑跡可抓方向，也有作用點的簇射；簇射光很強時，簡單的 LineFit 方向常常不可靠。'", "starting step")

# ---------------- RC0.7.1 UI semantic patch (B-UI-01) ----------------
src = rep(src, '<span class="step" data-s="4">⑤ 重建方向</span>', '<span class="step" data-s="4" id="step5Title">⑤ 方向重建示意</span>', "step5 title")
src = rep(src, '<label><input type="checkbox" id="tgReco" checked>重建方向</label>', '<label><input type="checkbox" id="tgReco" checked><span id="tgRecoLabel">顯示 LineFit 示意（可能失敗／反向）</span></label>', "reco checkbox")
src = rep(src, '<dt>真實來向</dt>', '<dt>模擬真值來向</dt>', "truth dir label")
src = rep(src, '<label><input type="checkbox" id="tgTrue" checked>真實路徑</label>', '<label><input type="checkbox" id="tgTrue" checked>模擬真值路徑</label>', "truth path label")
src = rep(src, "IceCube 再由這些時間反推微中子的來向。", "真實 IceCube 會用校準的探測器模型與重建方法估計事件；本頁的簡化 LineFit 只畫候選徑跡，可能嚴重失敗，甚至反向。", "brand text")
src = rep(src, "'用各 DOM 的到達時間與位置做 LineFit，反推 μ 子方向，也就是微中子的來向。'", "'利用 DOM 到達時間與位置做簡化 LineFit，估計一條候選徑跡；這個估計可能嚴重失敗，甚至翻轉方向，不能直接當成可信的微中子來向。'", "through story")
src = rep(src, "'有徑跡可抓方向，也有作用點的簇射；簇射光很強時，簡單的 LineFit 方向常常不可靠。'", "'這個事件同時有徑跡與簇射。簡化 LineFit 只給一條候選徑跡；簇射主導或命中幾何不利時可能嚴重失敗，甚至反向。'", "starting story")
src = rep(src, "'光幾乎對稱，時間序列幾乎不含方向資訊；電荷重心可估計頂點位置。本模型的光量未校準，不能用來反推真實能量。'", "'本教學級聯模型的光完全等向；命中不含入射方向資訊，因此不輸出方向重建。可觀察的是示意頂點、拓撲與相對光分布；光量未校準，不能反推真實能量。'", "cascade story")
src = rep(src, '      <span class="ev-name" id="evName">—</span>\n', '      <span class="ev-name" id="evName">—</span>\n      <div class="lf-disclose" id="lfDisclose" hidden><span id="lfDiscloseText">LineFit 是簡化的初步重建，只作示意；可能失敗，甚至反向。內部數值／幾何檢查不證明方向正確。擬合斜率是回歸參數，不是粒子或光子的速度。</span><span class="lf-legend" id="lfLegend">圖例：黃色實線＝模擬真值路徑；青色虛線＋箭頭＝候選 LineFit</span></div>\n', "disclosure overlay")
src = rep(src, ".ev-name{", ".lf-legend{display:block;margin-top:4px;color:#cfe6ff;font-size:11px}\n.lf-disclose{margin-top:6px;max-width:380px;font-size:12px;line-height:1.5;color:#fbe7b5;background:rgba(36,26,4,.82);border:1px solid #f2b84b;border-radius:6px;padding:6px 9px}\n.ev-name{", "disclosure css")
src = rep(src, "  if(V.reco){ V.reco.visible=$('tgReco').checked && done; }", "  if(V.reco){ V.reco.visible=$('tgReco').checked && done; }\n  $('lfDisclose').hidden = !(V.reco && V.reco.visible);", "disclosure toggle")
src = rep(src, "  $('evName').textContent = `${TYPE_NAME[ev.type]}・${fmtE(ev.E)}`;", "  $('evName').textContent = `${TYPE_NAME[ev.type]}・${fmtE(ev.E)}`;\n  { const isC = ev.type==='cascade'; $('step5Title').textContent = isC ? '⑤ 頂點與光分布' : '⑤ 方向重建示意'; $('tgRecoLabel').textContent = isC ? '顯示電荷重心示意' : '顯示 LineFit 示意（可能失敗／反向）'; }", "dynamic titles")

(ROOT / "app_template.html").write_text(src)
print("template written", len(src))
