# RC0.7 CHANGELOG

基準：RC0.6 candidate。範圍：只處理 RC0.6 重審的 computational／semantic blockers。

## 1. 變更

| ID | 變更 | 位置 |
|---|---|---|
| R01 | `safeNormalize()`；方向只需非零有限；`readTriple()` 每欄只讀一次、拒絕稀疏陣列與非原始數字 | `validateEventInput` |
| R02/R04 | 移除 USABLE／IDENTIFIABLE；新層級 FIT_COMPUTED → GEOMETRY_NONDEGENERATE → FIT_DISPLAYABLE（只看數值與幾何）；品質指標只作描述；`reconstructEvent()` 輸出附免責聲明；真實方向只在 `qa` | `lineFit`、`reconstructEvent`、`simulationQA` |
| R03 | 級聯不執行 LineFit、不輸出方向，`directionStatus = NOT_IDENTIFIABLE_IN_PEDAGOGICAL_CASCADE_MODEL` | `reconstructEvent` |
| R05 | 精確卜瓦松：μ < 10 Knuth、μ ≥ 10 PTRS；新增 `loggam`；RNG 異常時丟出錯誤 | `makeRandom` |
| R06 | Weibull 揭露（核心註解、app、文件）；不改形狀 | `WEIBULL_K` |
| R07 | 參數化分段交點積分；以下端點判定層；移除 10⁻⁹ 分支 | `opticalDepth` |
| R08 | `ENERGY_TOLERANCE`、`checkConservation()`；物理不變 | core §R08 |
| R09 | `tests/repro.mjs`（raw／canonical hash、容差比對）、`repro_child.mjs`、跨 Node 版本測試 | tests |


## 2. 刻意沒動

切倫科夫幾何（G1：與 RC0.5 Claude 逐位元相同，與 GPT 最大差 6.1e-10 ns）、能量帳本結構、光量常數、衰減常數、散射強度與 Weibull 形狀、LineFit 演算法本身、UI 取樣公式。

## 3. 會改變結果的地方

- **PTRS 取代常態近似**：μ ≥ 10 的抽樣路徑不同，所以同一個 seed 的命中結果會與 RC0.6 不同。能量帳本只用 `expo` 和 `rng`，不受影響。
- **R07 修正**只影響跨越層邊界、且深度差極小的路徑。
- **級聯事件不再有方向輸出**；徑跡狀態改名。

## 4. UI

- 標籤改為「RC0.7 候選」。
- 徑跡顯示「LineFit 示意」、模擬 QA 誤差與是否翻轉；LineFit 線一律用同一種虛線，顏色不再暗示可靠度。
- 級聯方向欄顯示「方向無法識別：NOT IDENTIFIABLE IN THIS PEDAGOGICAL CASCADE MODEL」，只畫電荷重心。
- 刪除所有「方向可用」「通過可信度檢查」類文字。
- 「模型說明」加入 Weibull 揭露與 LineFit 限制。

## 5. 永久回歸 fixtures

P0-01 MAX 方向溢位、P0-02 類比（起始徑跡 7006668 與 7003149：RC0.6 標為 USABLE 但方向翻到另一半球；GPT 的 seed 40003618 原始輸入無法取得）、P0-03 級聯 40005452 不可識別、稀疏 vertex、嚴格浮點能量（16051）、高 μ 切分（總 μ 100／1000／10000 × 10／100 份）、次奈米冰層跨越。全部寫在 `tests/run_all.mjs` 裡。
