# Cascade Identifiability（R03）

閘門 **PASS**；保留樣本閘門 **PASS**

## 1. 為什麼這不是門檻問題

本教學模型的級聯是**等向的點光源**：光量只取決於頂點、能量與 DOM 距離，與入射方向無關。所以把真實方向反過來，命中結果一模一樣。在數學上，命中裡不存在方向資訊。任何「級聯方向」的輸出都只是雜訊被擬合成一條線，不能靠提高相關係數門檻解決。

## 2. 驗證

- 200 個級聯事件（含永久 fixture seed 40005452）：把真實方向翻轉 180°，命中**逐位元相同**的事件數為 200 / 200。
- 輸出方向或擬合斜率的事件數：0。
- 保留樣本中的級聯共 15 格（3 種能量 × 5 個方向類別，每格 40 個事件，共 600 個）：方向輸出 0 次，全部標為不可識別。

永久 fixture（seed 40005452）：RC0.6 狀態 `IDENTIFIABLE`；RC0.7 `directionStatus = NOT_IDENTIFIABLE_IN_PEDAGOGICAL_CASCADE_MODEL`，`fitDirection = None`，頂點估計 `CHARGE_CENTROID_ILLUSTRATIVE`。

## 3. 輸出

- `directionStatus = NOT_IDENTIFIABLE_IN_PEDAGOGICAL_CASCADE_MODEL`；`fitDirection`、`fitSpeed`、`fitQualityMetrics` 都是 null。**對級聯不執行 LineFit。**
- 仍輸出電荷重心作為示意頂點（`CHARGE_CENTROID_ILLUSTRATIVE`），以及 model PE 光量。
- UI 方向欄顯示「方向無法識別：NOT IDENTIFIABLE IN THIS PEDAGOGICAL CASCADE MODEL」，並說明原因。

## 4. 範圍說明

這裡的事件類型是模擬中的模型假設（教學模型本來就知道）。真實資料沒有這個標籤；未來若要處理真實資料，需要另外做拓撲分類，而那需要外部校準。
