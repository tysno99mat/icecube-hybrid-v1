# Reconstruction Semantics（R02、R04）

閘門 **PASS**

## 1. 原則

**LineFit 不再判斷自己的方向可不可靠。** RC0.6 的「USABLE」被 GPT 的保留樣本推翻：相關係數 0.8 沒有天然斷點，調高門檻只是把誤判換成大量被拒絕的好徑跡。RC0.7 不再嘗試用 correlation 或 elongation 證明方向正確。

## 2. 狀態層級（只描述數值與幾何是否良定）

| 層級 | 條件 | 代表什麼 | **不**代表什麼 |
|---|---|---|---|
| FIT_NOT_COMPUTED | N < 4、非有限值、時間沒有分散、速度退化 | 沒有擬合結果 | — |
| FIT_COMPUTED | LineFit 有有限解 | 數字算得出來 | 方向正確 |
| GEOMETRY_NONDEGENERATE | ≥ 3 條纜線、時間跨度 ≥ 30 ns、點雲第三主軸 ≥ 5 m | 擬合問題在幾何上不退化 | 方向正確 |
| FIT_DISPLAYABLE | 再加上 N ≥ 8 | 可以畫成示意線 | **方向正確、可信、已驗證** |

伸長比、位置–時間相關係數與擬合斜率仍會回報在 `fitQualityMetrics`，但只是描述性數字，**不參與任何判定**。

## 3. 輸出契約

| 欄位 | 內容 |
|---|---|
| `reco.fitDirection`、`fitSpeed`、`fitPosition` | LineFit 的回歸結果；`fitSpeed` 是斜率，不是粒子速度，可能 > c |
| `reco.fitQualityMetrics` | 描述性指標，附註「不能證明方向準確」 |
| `reco.directionStatus` | `ILLUSTRATIVE_LINEFIT`／`NOT_AVAILABLE`／`NOT_IDENTIFIABLE_IN_PEDAGOGICAL_CASCADE_MODEL` |
| `reco.disclaimers` | 每個徑跡結果都帶有：*LineFit is an illustrative first-pass reconstruction.*、*Passing internal quality checks does not establish directional accuracy.*，以及擬合斜率說明 |
| `qa.trueDirection`、`angularError_deg`、`hemisphereFlip`、`vertexError_m` | **只存在於 `qa`（SIMULATION QA ONLY）**，重建函式從不接收真實方向 |

## 4. 禁用字詞掃描

核心程式（不含註解）與 app 模板中不得出現：USABLE、方向可用、方向通過可信度檢查、可靠方向、validated direction、reliable direction、direction confidence。掃描結果：無。

## 5. 徑跡 fixtures

| seed | E TeV | RC0.6 狀態與 QA 誤差 | RC0.7 狀態 | QA：翻到另一半球 | RC0.7 QA 誤差° |
|---|---|---|---|---|---|
| 7006668 | 100 | USABLE，98.0097° | FIT_DISPLAYABLE / ILLUSTRATIVE_LINEFIT | True | 98.0097 |
| 7003149 | 10 | USABLE，135.9686° | FIT_DISPLAYABLE / ILLUSTRATIVE_LINEFIT | True | 122.2332 |
| 40003618 | 100 | USABLE，3.5390° | FIT_DISPLAYABLE / ILLUSTRATIVE_LINEFIT | False | 6.1623 |


The exact GPT re-audit input for seed 40003618 was not available to Claude; under sampleEventInput('starting',100,'any',40003618) RC0.6 does not reproduce the 123.198° case. Two analogue fixtures (7006668, 7003149) found in a dedicated search range (7,000,000–7,008,000, excluded from the hold-out) reproduce the failure class: RC0.6 USABLE with the LineFit direction in the wrong hemisphere.

RC0.7 中這些事件仍然會畫出 LineFit 線（它本來就算得出來），但標示為示意，附上「可能失敗甚至翻轉」的說明，並在 QA 中顯示翻轉。這本身就是一個教學點。

## 6. 保留樣本描述（R10，只描述，不調參）

種子 900,000,000 – 900001799 (new; disjoint from RC0.6 tuning/re-audit seeds and from the 7,000,000–7,008,000 fixture search)。每格 40 個事件。

| 類型 | E TeV | 方向類別 | 可顯示比例 | QA 中位誤差° | 68%° | 90%° | 95%° | 翻轉比例 |
|---|---|---|---|---|---|---|---|---|
| through | 10 | up | 0.97 | 2.328 | 3.382 | 5.284 | 5.951 | 0 |
| through | 10 | down | 1 | 2.064 | 2.792 | 3.835 | 5.234 | 0 |
| through | 10 | horizontal | 0.95 | 1.750 | 2.762 | 3.904 | 4.106 | 0 |
| through | 10 | near_vertical_down | 0.90 | 2.615 | 4.139 | 5.075 | 5.543 | 0 |
| through | 10 | near_vertical_up | 0.97 | 2.438 | 2.933 | 4.269 | 5.693 | 0 |
| through | 100 | up | 1 | 2.947 | 4.676 | 10.641 | 13.141 | 0 |
| through | 100 | down | 1 | 3.638 | 4.892 | 7.696 | 9.392 | 0 |
| through | 100 | horizontal | 1 | 2.448 | 3.361 | 8.028 | 12.518 | 0 |
| through | 100 | near_vertical_down | 1 | 4.666 | 5.555 | 8.335 | 11.163 | 0 |
| through | 100 | near_vertical_up | 1 | 2.584 | 3.250 | 5.365 | 6.326 | 0 |
| through | 1000 | up | 1 | 3.212 | 4.170 | 8.286 | 11.093 | 0 |
| through | 1000 | down | 1 | 8.534 | 11.646 | 18.793 | 24.099 | 0 |
| through | 1000 | horizontal | 1 | 4.300 | 5.658 | 9.906 | 18.431 | 0 |
| through | 1000 | near_vertical_down | 1 | 7.479 | 10.397 | 22.903 | 26.349 | 0 |
| through | 1000 | near_vertical_up | 1 | 3.076 | 4.192 | 18.927 | 30.544 | 0 |
| starting | 10 | up | 1 | 4.481 | 9.204 | 41.547 | 83.072 | 0.050 |
| starting | 10 | down | 1 | 4.780 | 11.800 | 41.822 | 71.449 | 0.050 |
| starting | 10 | horizontal | 0.95 | 4.820 | 11.275 | 64.427 | 92.609 | 0.075 |
| starting | 10 | near_vertical_down | 1 | 5.189 | 15.547 | 62.605 | 106.822 | 0.100 |
| starting | 10 | near_vertical_up | 0.97 | 6.180 | 8.763 | 38.243 | 85.937 | 0.050 |
| starting | 100 | up | 1 | 13.711 | 31.838 | 119.495 | 136.317 | 0.175 |
| starting | 100 | down | 1 | 5.853 | 17.688 | 86.354 | 101.044 | 0.100 |
| starting | 100 | horizontal | 1 | 7.058 | 18.022 | 66.692 | 110.905 | 0.075 |
| starting | 100 | near_vertical_down | 1 | 8.525 | 23.446 | 73.892 | 82.543 | 0.025 |
| starting | 100 | near_vertical_up | 1 | 11.886 | 21.777 | 93.284 | 100.182 | 0.125 |
| starting | 1000 | up | 1 | 13.094 | 57.581 | 93.475 | 127.585 | 0.125 |
| starting | 1000 | down | 1 | 22.249 | 34.714 | 83.240 | 105.314 | 0.075 |
| starting | 1000 | horizontal | 1 | 13.688 | 35.509 | 108.531 | 140.672 | 0.175 |
| starting | 1000 | near_vertical_down | 1 | 10.822 | 30.852 | 84.914 | 90.506 | 0.075 |
| starting | 1000 | near_vertical_up | 1 | 35.969 | 91.754 | 154.096 | 166.066 | 0.350 |


**純雜訊點雲**（600 組，4–40 顆隨機命中）：{"n": 600, "statuses": {"FIT_DISPLAYABLE": 527, "GEOMETRY_NONDEGENERATE": 72, "FIT_COMPUTED": 1}}。大多數純雜訊也會達到 FIT_DISPLAYABLE，這說明「可顯示」只代表畫得出來，和方向是否正確無關。起始徑跡在 1000 TeV、近垂直上行時的翻轉比例高達 35%，這是簡單 LineFit 在簇射主導事件上的已知失敗模式。
