# Energy Tolerance Policy（R08）

閘門 **PASS**

## 1. 契約

```
tol = max(absTol, relTol · initialEnergy)，absTol = 1e-15 TeV，relTol = 1e-12
material conservation：|residual| ≤ tol，totalDeposited ≤ initial + tol，每一項 ≥ −tol
```

relTol = 10⁻¹² 大約比本教學模型宣稱的任何精度小 10⁹ 倍，所以不會掩蓋真實的能量創造（RC0.5 的錯誤是 2.4 倍）。

**沒有為了通過嚴格的 `<=` 去修改沉積物理。**

## 2. 結果（121,000 個合法事件）

| 檢查 | 失敗數 |
|---|---|
| 嚴格 IEEE（`deposited <= initial`） | 361（最大比值 1.0000000000000004） |
| **material conservation** | **0** |
| 最大相對殘差 | 8.53e-16 |

嚴格 IEEE 的失敗全部來自浮點捨入，例如幾個數相加後得到 1.0000000000000004 而不是 1。

## 3. 永久 fixture

`sampleEventInput('starting', 1, 'any', 16051)`：總沉積 1.0000000000000004 TeV，初始 1 TeV，比值 1.0000000000000004，殘差 -4.441e-16。嚴格 IEEE：False；material：True。

seed 1492（RC0.5 的原始失敗案例）：總沉積 53.9803 TeV，material True。
