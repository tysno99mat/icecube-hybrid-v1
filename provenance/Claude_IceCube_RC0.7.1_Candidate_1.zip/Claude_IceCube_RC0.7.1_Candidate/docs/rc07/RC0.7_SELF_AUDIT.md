# RC0.7 Self-Audit

**標示：`CLAUDE RC0.7 — READY FOR FINAL GPT COMPUTATIONAL-BASELINE AUDIT`**

這不是 PASS 宣告。Quantitative IceCube physics baseline 維持 **NO**。

## 1. 閘門

| 閘門 | 結果 |
|---|---|
| R01a_scale_safe_normalization | PASS |
| R01b_malformed_sparse_rejected | PASS |
| R03_cascade_never_claims_direction | PASS |
| R02_R04_linefit_never_claims_validation | PASS |
| R05_poisson_all_mu_and_partition | PASS |
| R06_weibull_disclosed | PASS |
| R07_ice_boundary_numeric_domain | PASS |
| R08_material_energy_conservation | PASS |
| G1_geometry_unchanged | PASS |
| G3_partition_mu1.5 | PASS |
| G8_causality_physical_time | PASS |
| R09a_same_platform_determinism | PASS |
| R09b_cross_runtime_numeric_contract | PASS |
| R10_holdout_cascade_outputs_none | PASS |

執行環境：Node v22.22.0、V8 12.4.254.21-node.33、linux x64；耗時約 27 秒。

## 2. 對 RC0.7 十項 gate 的對照

| # | 要求 | 狀態 |
|---|---|---|
| 1 | 尺度安全正規化 | PASS |
| 2 | 拒絕惡意與稀疏輸入 | PASS |
| 3 | 級聯從不宣稱物理方向 | PASS（另有保留樣本 PASS） |
| 4 | 徑跡 LineFit 從不自稱已驗證或可靠 | PASS |
| 5 | 高 μ 卜瓦松的統計切分一致 | PASS |
| 6 | 冰層邊界積分的數值範圍 | PASS |
| 7 | material energy conservation | PASS |
| 8 | 同平台決定性 | PASS |
| 9 | 跨平台數值重現契約已定義並測試 | PASS（只測了同一機器上的三個 Node 版本） |
| 10 | 沒有新的 P0 | 我自己沒找到；見 §3，**需要 GPT 判定** |

## 3. 我自己找到、可能被攻擊的地方

1. **P0-02 沒有逐字重現。** 我沒有拿到 GPT 重審的原始輸入；用 `sampleEventInput('starting', 100, 'any', 40003618)` 在 RC0.6 上得到的是 USABLE、3.5°，不是 123.198°。我另外找了兩個同類的類比 fixture。請把原始輸入定義一併提供，我會補成逐字的永久 fixture。
2. **純雜訊大多也是 FIT_DISPLAYABLE**（600 組中 527 組）。這符合新語意（「可顯示」只代表畫得出來），但如果有人只看層級名稱，可能會誤解。app 裡不會出現純雜訊事件，而且每個結果都帶有免責聲明。
3. **起始徑跡的翻轉比例相當高**（保留樣本最高 35%）。RC0.7 不擋、不調門檻，只標示並揭露。這是否構成「明顯錯誤卻自信地說是對的」，取決於 UI 免責聲明夠不夠清楚，需要外部判斷。
4. **方向契約放寬**：RC0.6 拒絕長度 ≤ 10⁻⁶ 的方向，RC0.7 接受任何非零有限向量。這是為了支援 [1e-308, 1e-308, 0] 的必要變更。
5. **非 2 的冪次縮放只保證 ulp 等級相同**，不保證逐位元相同。
6. **跨平台只在同一台 x64 機器的三個 Node 版本上測過**，三者的原始雜湊剛好相同。不同作業系統與 CPU 架構沒有測過。
7. **PTRS 的 log Γ** 用 NumPy 的 Stirling 級數；μ = 10¹² 抽查的平均與變異正確，但極端 μ 沒有做完整的 χ² 檢驗。
8. **事件類型**是模擬中的假設；級聯的不可識別性是本模型的性質，不是對真實 IceCube 的陳述。
9. **瀏覽器只做了 headless Chromium 測試**（離線版零網路請求、零錯誤；CDN 版以本機 three 代換後零錯誤），沒有在實體裝置上測試。

## 4. 結論

- Computational baseline candidate：**由 GPT 的 final computational-baseline audit 決定。**
- Quantitative IceCube physics baseline：**NO**，在沒有外部校準之前不改變。
