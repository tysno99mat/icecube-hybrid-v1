# Input Numerical Safety（R01）

閘門：R01a 尺度安全正規化 **PASS**；R01b 惡意與稀疏輸入拒絕 **PASS**

## 1. 修正內容

- `safeNormalize(v)`：先除以最大分量的絕對值，再取長度、再除一次。不會溢位，也不會下溢。
- **方向的合法條件改成**：三個有限的原始數字，而且不全為零，大小不限。RC0.6 拒絕長度 ≤ 10⁻⁶ 的方向；因為方向與尺度無關，RC0.7 取消這個任意門檻。這是契約變更，請反向審查。
- `readTriple()`：每個欄位**只讀一次**存成原始值；必須是長度 3 的稠密陣列（逐一檢查 `hasOwnProperty`）；元素必須是 `typeof 'number'` 且有限。Number 物件、字串、布林、BigInt、typed array、類陣列物件、會丟例外的 Proxy 或 getter 一律拒絕。
- 輸入物件本身的欄位也只讀一次；讀取時丟例外會回傳 `INVALID_INPUT`，不會讓程式崩潰。

## 2. 合法極端方向

| fixture | 合法 | 單位向量 | 與預期最大差 | 長度 |
|---|---|---|---|---|
| MAX_MAX_0 | True | [0.707107, 0.707107, 0] | 1.11e-16 | 1 |
| MAX_MAX_MAX | True | [0.577350, 0.577350, 0.577350] | 0 | 1 |
| MAX_1_0 | True | [1, 5.56268e-309, 0] | 0 | 1 |
| 1e-308_1e-308_0 | True | [0.707107, 0.707107, 0] | 1.11e-16 | 1 |
| min_subnormal | True | [1, 0, 0] | 0 | 1 |
| neg_MAX | True | [-0.707107, 0, 0.707107] | 1.11e-16 | 1 |
| ordinary | True | [0.600000, -0.800000, 0] | 0 | 1 |


永久 fixture **P0-01**：RC0.6 把 `[MAX, MAX, 0]` 正規化成 `[0, 0, 0]`；RC0.7 得到 `[0.70710678118654746, 0.70710678118654746, 0]`。

## 3. 重新縮放

- **2 的冪次縮放**（2⁻¹⁰⁰⁰、2⁻⁶⁰、2⁴⁰、2¹⁰⁰⁰）：單位向量與整個事件**逐位元相同**，共 12 個方向 × 4 個倍率。
- **非 2 的冪次縮放**（10⁻³⁰⁰、3.7、10³⁰⁰）：單位向量最多差 2.22e-16（約 1 ulp）。由於一個 ulp 的差異可能改變後續的浮點路徑，這類縮放只保證在 ulp 等級內相同，不保證逐位元相同。

## 4. 惡意輸入（37 個）

| fixture | 結果 | 說明 |
|---|---|---|
| zero_vector | INVALID_INPUT | direction must not be the zero vector |
| negative_zero | INVALID_INPUT | direction must not be the zero vector |
| NaN_direction | INVALID_INPUT | direction[0] must be a finite primitive number |
| Infinity_direction | INVALID_INPUT | direction[0] must be a finite primitive number |
| -Infinity_direction | INVALID_INPUT | direction[1] must be a finite primitive number |
| hole_direction | INVALID_INPUT | direction[1] is a hole (sparse array) |
| sparse_vertex_length3 | INVALID_INPUT | vertex[2] is a hole (sparse array) |
| direction_len2 | INVALID_INPUT | direction must have length 3 |
| direction_len4 | INVALID_INPUT | direction must have length 3 |
| string_component | INVALID_INPUT | direction[0] must be a finite primitive number |
| Number_object | INVALID_INPUT | direction[0] must be a finite primitive number |
| boolean_component | INVALID_INPUT | direction[0] must be a finite primitive number |
| bigint_component | INVALID_INPUT | direction[0] must be a finite primitive number |
| typed_array | INVALID_INPUT | direction must be an array |
| array_like_object | INVALID_INPUT | direction must be an array |
| throwing_proxy | INVALID_INPUT | direction[0] unreadable |
| zero_energy | INVALID_INPUT | energy 0 TeV outside contract [0.1, 100000] TeV |
| negative_energy | INVALID_INPUT | energy -1 TeV outside contract [0.1, 100000] TeV |
| NaN_energy | INVALID_INPUT | energy must be a finite primitive number |
| Infinity_energy | INVALID_INPUT | energy must be a finite primitive number |
| huge_energy_1e12 | INVALID_INPUT | energy 1000000000000 TeV outside contract [0.1, 100000] TeV |
| tiny_energy_1e-12 | INVALID_INPUT | energy 1e-12 TeV outside contract [0.1, 100000] TeV |
| Number_energy | INVALID_INPUT | energy must be a finite primitive number |
| unsupported_type | INVALID_INPUT | unsupported type: double_bang |
| String_object_type | INVALID_INPUT | unsupported type: object |
| NaN_vertex | INVALID_INPUT | vertex[0] must be a finite primitive number |
| bedrock_vertex | INVALID_INPUT | vertex depth 2900 m outside contract [1200, 2700] m |
| above_surface | INVALID_INPUT | vertex depth -10 m outside contract [1200, 2700] m |
| outside_detector_x | INVALID_INPUT | vertex outside contract volume (|x|,|z| ≤ 800 m) |
| seed_float | INVALID_INPUT | seed must be an integer primitive in [0, 2^32-1] |
| seed_negative | INVALID_INPUT | seed must be an integer primitive in [0, 2^32-1] |
| seed_string | INVALID_INPUT | seed must be an integer primitive in [0, 2^32-1] |
| seed_too_big | INVALID_INPUT | seed must be an integer primitive in [0, 2^32-1] |
| null_input | INVALID_INPUT | input must be a plain object |
| array_input | INVALID_INPUT | input must be a plain object |
| throwing_getter_input | INVALID_INPUT | input fields unreadable |
| getter_read_once | OK(read once) | 讀取 1 次 |


- `getter_read_once`：第一次讀取回傳 1、之後回傳 NaN 的 getter。RC0.7 只讀一次，所以使用的是 1，不會在檢查與計算之間被換成 NaN。
- **稀疏 vertex 永久 fixture**：RC0.6 接受 `[0, −2000, 空洞]`（`True`），因為 `Array.every` 會跳過空洞；RC0.7 拒絕。
- UI 取樣器產生的 30,000 個輸入，被拒絕 0 個。
