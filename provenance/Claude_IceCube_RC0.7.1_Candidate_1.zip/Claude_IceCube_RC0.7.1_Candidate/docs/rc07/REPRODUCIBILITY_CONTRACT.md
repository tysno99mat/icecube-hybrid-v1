# Reproducibility Contract（R09）

閘門：R09a 同平台 **PASS**；R09b 跨執行環境數值 **PASS**

## 1. 兩層契約

| 層 | 條件 | 要求 |
|---|---|---|
| SAME_PLATFORM_DETERMINISM | 同一執行環境、同一架構、同一輸入、同一 seed | 原始結果的 JSON（IEEE 雙精度）**逐位元相同** |
| CROSS_PLATFORM_NUMERICAL_REPRODUCIBILITY | 不同的受支援執行環境或平台 | 所有科學觀測量在容差內相同：浮點數相對 1e-09、絕對 1e-12；整數、字串、布林必須完全相同 |

- **不要求跨平台的原始浮點數雜湊相同。**
- **canonical hash**：欄位排序固定、浮點數四捨五入到 12 位有效數字後再雜湊，只用來辨識產出物。原始結果一律保留，canonicalization 不能用來掩蓋真正的差異；權威的跨平台檢查是 `compareWithTolerance()`。
- `tests/compare_frozen.mjs` 依同一容差，把新跑的結果和 `results_frozen/` 比對，並排除執行環境中繼資料與雜湊欄位。

## 2. 實測

- **同平台**：連跑兩次加上一個全新子程序，原始雜湊都是 `2142983fb31df7cf…`。
- **跨執行環境**（同一台 linux x64 機器上的三個 Node/V8 版本）：

| 執行環境 | 原始雜湊 | canonical 雜湊 | 容差內相同 | 最大相對差 |
|---|---|---|---|---|
| node v20.20.0 / V8 11.3.244.8-node.33 | 2142983fb31df7cf… | 39533b8b54603209… | True | 0 |
| node v21.7.3 / V8 11.8.172.17-node.20 | 2142983fb31df7cf… | 39533b8b54603209… | True | 0 |
| node v22.22.0 / V8 12.4.254.21-node.33 | 2142983fb31df7cf… | 39533b8b54603209… | True | 0 |


## 3. 沒有測到的

- 不同作業系統與不同 CPU 架構（例如 darwin arm64）。GPT 的 RC0.6 重審在 darwin arm64 上看到原始雜湊不同，而這正是新契約要容許的情況。
- 本機有其他 Node 版本時，可設定 `ICECUBE_ALT_NODES=/path/node20:/path/node21` 再執行；找不到其他版本時，R09b 會標為 SKIPPED（不計為通過），並指向凍結的證據。
