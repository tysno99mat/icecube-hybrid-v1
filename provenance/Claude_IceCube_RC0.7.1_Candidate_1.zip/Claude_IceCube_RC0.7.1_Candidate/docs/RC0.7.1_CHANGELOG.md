# RC0.7.1 CHANGELOG — Baseline Gate Fix

**標示：`CLAUDE RC0.7.1 — READY FOR TWO-BLOCKER GPT GATE CHECK`**

這是 release-gate 修補，不是新的物理版本。只處理 GPT `HYBRID_BASELINE_GATE.md` 的兩個必修項：B-INPUT-01 與 B-UI-01。沒有建立 Hybrid，沒有部署。

## 1. 變更

| ID | 變更 | 位置 |
|---|---|---|
| B-INPUT-01 | `validateEventInput()` 外層加上例外防護。任何驗證操作只要丟出例外（`Array.isArray` 碰到 revoked Proxy、getter、length、元素讀取），就回傳 `INVALID_INPUT`。`readTriple()` 裡的 `Array.isArray` 另外再包一層 | `src/core.mjs` |
| B-INPUT-01 | 新增測試用計數器 `_counters`（RNG 串流數、物理執行次數），只在測試中讀取，不影響任何結果 | `src/core.mjs` |
| B-UI-01 | 首次接觸的文案全部改寫，依 `UI_SEMANTIC_AUDIT.md` 的必要替換文字，詳見 `UI_SEMANTIC_PATCH.md` | `app/patch_app.py` → `app/app_template.html` → 所有 `dist/` |
| B-UI-01 | 品牌介紹末句改用 GPT 的原文：「真實 IceCube 會用校準的探測器模型與重建方法估計事件；本頁的簡化 LineFit 只畫候選徑跡，可能嚴重失敗，甚至反向。」 | 同上 |
| B-UI-01 | 常駐揭露框加上圖例：「圖例：黃色實線＝模擬真值路徑；青色虛線＋箭頭＝候選 LineFit」（採用 GPT 非強制建議中的「同時可見圖例」方案；LineFit 預設仍顯示） | 同上 |
| 建議項 | `FIT_DISPLAYABLE` 改名為 `FIT_RENDERABLE`（只改字串，數值不變） | core、tests、UI |
| 建置 | 離線版改用 `--charset=utf8` 打包，中文字串以原文保存，可以直接做靜態掃描 | `build/build.mjs` |
| 回放 | `compare_frozen.mjs` 不再把 strict IEEE roundoff 計數當成 snapshot 差異（理由見第 5 節） | `tests/compare_frozen.mjs` |
| 中繼資料 | `package.json`／`package-lock.json` 的名稱與版本改為 `claude-icecube-rc071`／`0.7.1-candidate`；`REPRODUCE.sh` 標題改為 RC0.7.1 | 根目錄 |

## 2. 沒有改動的部分

切倫科夫幾何、能量帳本、光源劃分、卜瓦松抽樣、散射模型、冰層傳輸、LineFit 數學、事件產生、QA 計算、偵測器幾何，全都沒有改動。

**G17 驗證了這一點**：306 個事件（300 個涵蓋各種類型、能量與方向，另加 6 個永久 fixture）與 RC0.7 核心比較，命中、時間、電荷、能量帳本、擬合結果、頂點與 QA 數值**逐位元相同**（306/306）。唯一的差別是狀態字串改名，比較時已做對應。

## 3. 回歸閘門

| 閘門 | 結果 |
|---|---|
| R01a_scale_safe_normalization | PASS |
| R01b_malformed_sparse_rejected | PASS |
| R03_cascade_never_claims_direction | PASS |
| R02_R04_linefit_never_claims_validation | PASS |
| R05_poisson_all_mu_and_partition | PASS |
| R06_weibull_disclosed | PASS |
| R07_ice_boundary_numeric_domain | PASS |
| R08_material_energy_conservation | PASS |
| G1_geometry_unchanged | PASS |
| G3_partition_mu1.5 | PASS |
| G8_causality_physical_time | PASS |
| R09a_same_platform_determinism | PASS |
| R09b_cross_runtime_numeric_contract | PASS |
| R10_holdout_cascade_outputs_none | PASS |
| G15_revoked_proxy_safety | PASS |
| G16_semantic_first_contact_static | PASS |
| G17_physics_identical_to_rc07 | PASS |
| G18_exact_GPT_fixtures_still_wrong_but_illustrative | PASS |
| UI runtime（headless Chromium，離線版與 CDN 版 × 桌機與手機寬度） | PASS |

R09 的原始雜湊從 RC0.7 的 `2142983f…` 變成 `f1cc49af…`，原因只是狀態字串改名（`strip()` 包含 `fitStatus`）。三個 Node 版本之間仍然逐位元相同。

## 4. 精確 fixture：seed 40003618（G18）

GPT 的 `P0_REGRESSION_RESULTS.json` 提供了原始 EventInput，現在已經**精確重現**：

| fixture | seed | 類型 | E (TeV) | clean | QA 角度誤差 | 翻到另一半球 | fitStatus | directionStatus | RC0.7 誤差 | RC0.6 狀態 | 與 GPT 數值一致 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P0-02 exact | 40003618 | starting | 100 | 29 | 123.197987° | 是 | FIT_RENDERABLE | ILLUSTRATIVE_LINEFIT | 123.197987° | USABLE | 是 |
| analogue 7006668 (GPT exact input) | 7006668 | starting | 100 | 37 | 98.009732° | 是 | FIT_RENDERABLE | ILLUSTRATIVE_LINEFIT | 98.009732° | USABLE | 是 |
| analogue 7003149 (GPT exact input) | 7003149 | starting | 10 | 30 | 122.233247° | 是 | FIT_RENDERABLE | ILLUSTRATIVE_LINEFIT | 122.233247° | USABLE | 是 |

- P0-02 的輸入：vertex `[13.51335848642547, -2054.7249785158783, -349.13105856992416]`，direction `[0.254969431141881, 0.5841294150450267, -0.7705734330109887]`。
- RC0.7.1 的結果：29 個 clean hits，誤差 123.19798699754°，擬合方向 `[-0.16878987102916515, -0.9815906190142011, -0.08938588312074396]`。這與 RC0.6 和 RC0.7 逐位元相同。
- 這條線**仍然是錯的**，而且這次沒有試圖修正它。產品只把它標為 `FIT_RENDERABLE`／`ILLUSTRATIVE_LINEFIT`，三條免責聲明都在，QA 標示 `SIMULATION QA ONLY`。RC0.6 曾把同一個事件標成 `USABLE`，這正是 RC0.7 移除那套語意的原因。
- 這三個輸入已成為永久回歸閘門 G18，完整輸出在 `results_frozen/EXACT_GPT_FIXTURES.json`。
- 任何其他輸入可以用 `node tests/check_fixture.mjs '<EventInput JSON>'` 在幾秒內檢查。

## 5. 回放政策：strict IEEE roundoff 計數

GPT 在 Darwin arm64 上回放時，strict-roundoff 計數從 361 變成 357，導致 7/9 snapshot 相符，回放判為 PARTIAL。GPT 自己的裁決是「不是 material physics failure」，而 strict roundoff 也不在阻擋項內。

因此 `compare_frozen.mjs` 現在把 `strict_IEEE_failures`、`worst_strict_ratio`、`strictFail`、`worstStrict` 以及 runtime 描述欄位當成診斷資訊；UI runtime 檔中的時間戳 `source` 與隨機事件的 QA 讀數 `stReco` 也一樣（UI 每次載入會抽不同事件），不列入比較。**material 失敗數（relTol 1e-12）仍然逐欄比較**，任何一筆 material failure 都會讓 R08 失敗。這是放寬回放比對，不是放寬物理容差。

## 6. 疏漏說明

RC0.7 的禁用字詞掃描其實掃不到離線版：esbuild 預設會把中文轉成 `\uXXXX` 跳脫，所以在 JS 字串裡找不到中文。這次改用 UTF-8 打包後才真正掃到。RC0.7 的模板與 CDN 版本身沒有禁用字詞，離線版內容又與它們相同，所以結論不受影響。但「RC0.7 掃描過離線版」這句話當時並不成立。

## 7. 仍然沒有驗證的部分

- 實體裝置、真實 GPU／WebGL、觸控互動：這次只有 headless Chromium。
- 跨 OS／ARM 的逐事件數值驗證：這裡只有 Linux x64 上的三個 Node 版本。
- `QUANTITATIVE ICECUBE PHYSICS BASELINE = NO`，不變。
