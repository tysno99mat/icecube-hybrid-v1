# UI Semantic Patch（B-UI-01）＋ Input Proxy Safety（B-INPUT-01）

**標示：`CLAUDE RC0.7.1 — READY FOR TWO-BLOCKER GPT GATE CHECK`**

## 1. 文案變更（所有出貨版本同步）

| 位置 | 舊 | 新 |
|---|---|---|
| 徑跡第 5 步標題 | ⑤ 重建方向 | **⑤ 方向重建示意** |
| 級聯第 5 步標題 | （共用徑跡標題） | **⑤ 頂點與光分布**（依事件類型動態切換） |
| 品牌介紹末句 | IceCube 再由這些時間反推微中子的來向。 | **真實 IceCube 會用校準的探測器模型與重建方法估計事件；本頁的簡化 LineFit 只畫候選徑跡，可能嚴重失敗，甚至反向。**（GPT 原文） |
| 徑跡勾選框 | 重建方向 | **顯示 LineFit 示意（可能失敗／反向）** |
| 級聯勾選框 | 重建方向 | **顯示電荷重心示意** |
| 穿越徑跡故事 | 用各 DOM 的到達時間與位置做 LineFit，反推 μ 子方向，也就是微中子的來向。 | 利用 DOM 到達時間與位置做簡化 LineFit，估計一條候選徑跡；這個估計可能嚴重失敗，甚至翻轉方向，不能直接當成可信的微中子來向。 |
| 起始徑跡故事 | 有徑跡可抓方向，也有作用點的簇射；… | 這個事件同時有徑跡與簇射。簡化 LineFit 只給一條候選徑跡；簇射主導或命中幾何不利時可能嚴重失敗，甚至反向。 |
| 級聯故事 | 光幾乎對稱，… | 本教學級聯模型的光完全等向；命中不含入射方向資訊，因此不輸出方向重建。可觀察的是示意頂點、拓撲與相對光分布；光量未校準，不能反推真實能量。 |
| 讀數 | 真實來向 | **模擬真值來向** |
| 顯示選項 | 真實路徑 | **模擬真值路徑** |
| QA 用語 | 與真實方向差、真實頂點 | 與模擬真值方向差、模擬真值頂點 |
| 標籤 | RC0.7 候選 | RC0.7.1 候選 |

**與 GPT 原文唯一的差異**：起始徑跡故事採用 RC0.7.1 指令中的版本，比 GPT 審查表多了「或命中幾何不利」幾個字。這只多列出一種失敗情境，沒有減弱任何警語。若 GPT 要求逐字一致，改一行即可。

**常駐揭露**：3D 視窗左上角、事件名稱正下方，有一個琥珀色框：

> LineFit 是簡化的初步重建，只作示意；可能失敗，甚至反向。內部數值／幾何檢查不證明方向正確。擬合斜率是回歸參數，不是粒子或光子的速度。
>
> 圖例：黃色實線＝模擬真值路徑；青色虛線＋箭頭＝候選 LineFit

這個框與 LineFit 候選線**同步顯示和隱藏**：線出現時框就出現，取消勾選時兩者一起消失。級聯事件沒有候選線，所以不顯示這個框。它不在折疊區或說明頁裡，也不會被擠出視窗。圖例的顏色與 renderer 一致：真值路徑是 `0xffd166` 實線，候選線是 `0x36e2c3` 虛線加箭頭。候選線不會依誤差或 hemisphereFlip 改變顏色。

## 2. 出貨版本

`app/app_template.html` → `build/build.mjs` → `dist/icecube_rc071.html`（CDN）、`dist/icecube_rc071_artifact_body.html`（artifact 格式）、`dist/offline/index.html`（離線）。三個版本都由同一份模板建置，沒有手動修改的版本。

## 3. G16 檢查

**靜態檢查**（`tests/run_all.mjs`，涵蓋四個檔案）：禁用字詞出現 0 次，包括重建方向、可信方向、方向可用、有徑跡可抓方向、方向通過可信度檢查、可靠方向、真實來向、真實路徑、USABLE、FIT_DISPLAYABLE。所有新文案、品牌原文與揭露全文都存在。結果：**PASS**。

**執行期檢查**（`tests/ui_runtime_check.mjs`，headless Chromium，依序切換穿越、起始、級聯，再回到穿越）。揭露文字與圖例分別以全文逐字比對：

| 版本 | 寬度 | 類型 | 第 5 步標題 | 勾選框 | t=0 時揭露隱藏 | 結束時揭露在視窗內 | 禁用字 | 結果 |
|---|---|---|---|---|---|---|---|---|
| dist/offline/index.html | 1400x860 | through | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/offline/index.html | 1400x860 | starting | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/offline/index.html | 1400x860 | cascade | ⑤ 頂點與光分布 | 顯示電荷重心示意 | 是 | 否 | 無 | PASS |
| dist/offline/index.html | 1400x860 | through | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/offline/index.html | 400x860 | through | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/offline/index.html | 400x860 | starting | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/offline/index.html | 400x860 | cascade | ⑤ 頂點與光分布 | 顯示電荷重心示意 | 是 | 否 | 無 | PASS |
| dist/offline/index.html | 400x860 | through | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/icecube_rc071.html | 1400x860 | through | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/icecube_rc071.html | 1400x860 | starting | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/icecube_rc071.html | 1400x860 | cascade | ⑤ 頂點與光分布 | 顯示電荷重心示意 | 是 | 否 | 無 | PASS |
| dist/icecube_rc071.html | 1400x860 | through | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/icecube_rc071.html | 400x860 | through | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/icecube_rc071.html | 400x860 | starting | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |
| dist/icecube_rc071.html | 400x860 | cascade | ⑤ 頂點與光分布 | 顯示電荷重心示意 | 是 | 否 | 無 | PASS |
| dist/icecube_rc071.html | 400x860 | through | ⑤ 方向重建示意 | 顯示 LineFit 示意（可能失敗／反向） | 是 | 是 | 無 | PASS |

截圖在 `qa/`。這是 headless 測試，不是實體裝置測試。

## 4. G15 revoked Proxy

| fixture | 結果 | physicsCalls | rngCalls | optionsReads | 未捕捉例外 | 錯誤訊息 |
|---|---|---|---|---|---|---|
| revoked_event_proxy | INVALID_INPUT | 0 | 0 | 0 | 否 | input validation raised TypeError |
| revoked_vertex_proxy | INVALID_INPUT | 0 | 0 | 0 | 否 | vertex is not inspectable (e.g. revoked Proxy) |
| revoked_direction_proxy | INVALID_INPUT | 0 | 0 | 0 | 否 | direction is not inspectable (e.g. revoked Proxy) |
| revoked_event_proxy_cascade | INVALID_INPUT | 0 | 0 | 0 | 否 | input validation raised TypeError |

- **RC0.7 在同樣三個 fixture 上的行為**：revoked_event_proxy → THREW TypeError；revoked_vertex_proxy → THREW TypeError；revoked_direction_proxy → THREW TypeError。
- **合法輸入的尺度安全行為不變**：[1.7976931348623157e+308, 1.7976931348623157e+308, 0] ok=True，與 RC0.7 相同=True；[5e-324, 0, 0] ok=True，與 RC0.7 相同=True；[1e-308, 1e-308, 0] ok=True，與 RC0.7 相同=True；[3, -4, 0] ok=True，與 RC0.7 相同=True。沒有加入任意的大小門檻。
- **計數方式**：`optionsReads` 用一個 Proxy 當作 options 傳入，記錄 get、ownKeys、getOwnPropertyDescriptor、has 四種操作。`physicsRuns` 與 `rngStreams` 是核心內部的計數器，只在驗證通過後才遞增。
