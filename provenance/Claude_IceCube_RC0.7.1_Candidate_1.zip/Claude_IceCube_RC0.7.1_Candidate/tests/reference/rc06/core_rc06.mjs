// Claude IceCube physics core — RC0.6 candidate
// Pure JavaScript, no dependencies. Single source of truth for the app and for the regression tests.
//
// RC0.6 scope (B01–B06 only):
//   B01 energy ledger            B02 energy→light source accounting
//   B03 multi-source timing      B04 piecewise ice transport
//   B05 EventInput contract      B06 reconstruction validity tiers
// Unchanged on purpose: DOM geometry, Cherenkov emission geometry and direct-time formula (validated in RC0.5),
// refractive indices, LC cleaning, noise rate, scattering mean law (0.8·d/n^0.7), light-yield constants.
//
// THIS IS AN UNCALIBRATED TEACHING MODEL. "model PE" is a relative light-yield unit, not an IceCube prediction.

export const VERSION = 'claude-icecube-core RC0.6-candidate';

/* ---------------- constants ---------------- */
export const C = 0.299792458;                 // m/ns
export const DEFAULT_N_PHASE = 1.32, DEFAULT_N_GROUP = 1.35;   // unchanged from RC0.5 (B09 out of scope)
export const BEDROCK = 2820;                  // m
export const A_CASC = 220;                    // model PE per TeV deposited (point-source normalisation; UNCALIBRATED)
export const B_TRACK = 17;                    // bare-muon Cherenkov amplitude (UNCALIBRATED)
export const A_ION = 2.6e-4;                  // TeV/m continuous (ionisation-like) loss — textbook order of magnitude, UNVERIFIED
export const STOCH_RATE = 0.004;              // resolved stochastic losses per metre (= 4 per km, unchanged from RC0.5)
export const STOCH_FRAC_MEAN = 0.06, STOCH_FRAC_MAX = 0.5;   // fraction of REMAINING energy (RC0.5 used initial energy)
export const DELAY_COEF = 0.8;                // ns per metre, mean first-photon delay for n=1 (unchanged)
export const DELAY_EXP = 0.7;                 // first-of-n mean ∝ n^-0.7 (unchanged)
export const WEIBULL_K = 1 / DELAY_EXP;       // per-photon delay shape that reproduces the n^-0.7 law exactly (B03)
const GAMMA_1P7 = 0.9086387328532904;         // Γ(1 + 0.7) — checked numerically in tests
export const DARK_RATE_PER_NS = 5e-7;         // 500 Hz (unchanged)
export const JITTER_NS = 2;                   // electronics timestamp jitter (measurement, not physics)
export const MU_MIN = 1e-9;                   // sources with expected PE below this are skipped (documented bias ≤ 1e-9 per source)

/* ---------------- RNG ---------------- */
export function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}}
function makeRandom(rng){
  const gauss = () => { let u=0; while(!u) u=rng(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*rng()); };
  const expo = m => -m*Math.log(1-rng());
  const poisson = mu => { if(!(mu>0)) return 0; if(mu>30) return Math.max(0,Math.round(mu+Math.sqrt(mu)*gauss())); const L=Math.exp(-mu); let k=0,p=1; do{k++;p*=rng();}while(p>L && k<1000); return k-1; };
  return { rng, gauss, expo, poisson };
}

/* ---------------- detector geometry (verbatim from RC0.5) ---------------- */
function linspace(a,b,n){const o=[];for(let i=0;i<n;i++)o.push(a+(b-a)*i/(n-1));return o;}
export const strings = [];
{
  const S = 125, pts = [];
  for(let q=-6;q<=6;q++) for(let r=-6;r<=6;r++){
    const hd=(Math.abs(q)+Math.abs(r)+Math.abs(q+r))/2; if(hd>5) continue;
    const x=S*(q+r/2), z=S*(r*Math.sqrt(3)/2);
    pts.push({x,z,d:Math.hypot(x*0.9,z*1.12)});
  }
  pts.sort((a,b)=>a.d-b.d);
  const std = pts.slice(0,78).sort((a,b)=>(a.z-b.z)||(a.x-b.x));
  std.forEach((p,i)=>strings.push({id:i+1,x:p.x,z:p.z,deep:false}));
  const dc=[];
  for(let k=0;k<6;k++){const a=Math.PI/6+k*Math.PI/3; dc.push([72*Math.cos(a),72*Math.sin(a)]);}
  dc.push([144*Math.cos(Math.PI/6),144*Math.sin(Math.PI/6)]);
  dc.push([144*Math.cos(7*Math.PI/6),144*Math.sin(7*Math.PI/6)]);
  dc.forEach((p,i)=>strings.push({id:79+i,x:p[0],z:p[1],deep:true}));
}
const STD_DEPTHS = linspace(1450,2450,60);
const DC_DEPTHS = [...linspace(1750,1850,10), ...linspace(2100,2450,50)];
export const doms = [];
export const domsByString = new Map();
for(const s of strings){
  const arr=[]; (s.deep?DC_DEPTHS:STD_DEPTHS).forEach((d,i)=>{ const idx=doms.length; doms.push({idx,str:s.id,om:i+1,x:s.x,y:-d,z:s.z,depth:d}); arr.push(idx); });
  domsByString.set(s.id,arr);
}
export const inIce = y => y<0 && y>-BEDROCK;

/* ---------------- B04: ice transport (piecewise-exact optical depth) ---------------- */
// Same piecewise inverse attenuation length as RC0.5 (values UNCALIBRATED); only the integration changes.
const LAYERS = [ [0,1400,1/10], [1400,2000,1/42], [2000,2100,1/16], [2100,2450,1/70], [2450,BEDROCK,1/60] ];
export function invLambda(depth){
  if(depth<0) return 1;
  for(const [a,b,v] of LAYERS) if(depth<b) return v;
  return 1;
}
// F(d) = ∫_0^d invLambda(z) dz, exact for the piecewise-constant profile (outside ice: 1/m).
function cumInv(d){
  if(d<=0) return d*1;                 // negative depth (above surface): opaque convention, inv = 1/m
  let s=0;
  for(const [a,b,v] of LAYERS){ if(d<=a) return s; const hi=Math.min(d,b); s+=(hi-a)*v; if(d<=b) return s; }
  return s + (d-BEDROCK)*1;
}
// optical depth τ along the straight segment between heights yA and yB with length L (m)
export function opticalDepth(yA, yB, L){
  const dA=-yA, dB=-yB, dz=Math.abs(dB-dA);
  if(!(L>0)) return 0;
  if(dz < 1e-9) return L*invLambda((dA+dB)/2);
  return L*Math.abs(cumInv(dB)-cumInv(dA))/dz;
}
// RC0.5 three-point estimate, kept ONLY for regression comparison
export function opticalDepthThreePointLegacy(yA,yB,L){ const d1=-yA,d2=-yB; return L*(invLambda(d1)+invLambda((d1+d2)/2)+invLambda(d2))/3; }

/* ---------------- B05: EventInput contract ---------------- */
export const CONTRACT = {
  types: ['through','starting','cascade'],
  energyTeV: [0.1, 1e5],          // UI exposes 1–10,000 TeV
  maxHorizontal_m: 800,           // |x| and |z| of the vertex / track anchor
  depth_m: [1200, 2700],          // vertex / anchor depth range (inside ice, above bedrock)
  minDirNorm: 1e-6,
  seed: [0, 4294967295],
};
export function validateEventInput(input){
  const errors=[]; const fin = v => typeof v==='number' && Number.isFinite(v);
  if(!input || typeof input!=='object') return {ok:false, code:'INVALID_INPUT', errors:['input must be an object']};
  const {seed,type,vertex,direction,energy} = input;
  if(!Number.isInteger(seed) || seed<CONTRACT.seed[0] || seed>CONTRACT.seed[1]) errors.push('seed must be an integer in [0, 2^32-1]');
  if(!CONTRACT.types.includes(type)) errors.push(`unsupported type: ${String(type)}`);
  if(!Array.isArray(vertex) || vertex.length!==3 || !vertex.every(fin)) errors.push('vertex must be 3 finite numbers');
  else {
    const depth=-vertex[1];
    if(Math.abs(vertex[0])>CONTRACT.maxHorizontal_m || Math.abs(vertex[2])>CONTRACT.maxHorizontal_m) errors.push(`vertex outside contract volume (|x|,|z| ≤ ${CONTRACT.maxHorizontal_m} m)`);
    if(!(depth>=CONTRACT.depth_m[0] && depth<=CONTRACT.depth_m[1])) errors.push(`vertex depth ${depth} m outside contract [${CONTRACT.depth_m[0]}, ${CONTRACT.depth_m[1]}] m`);
  }
  let unit=null;
  if(!Array.isArray(direction) || direction.length!==3 || !direction.every(fin)) errors.push('direction must be 3 finite numbers');
  else {
    const n=Math.hypot(direction[0],direction[1],direction[2]);
    if(!(n>CONTRACT.minDirNorm)) errors.push(`direction norm ${n} too small`);
    else unit=[direction[0]/n,direction[1]/n,direction[2]/n];
  }
  if(!fin(energy)) errors.push('energy must be finite');
  else if(!(energy>=CONTRACT.energyTeV[0] && energy<=CONTRACT.energyTeV[1])) errors.push(`energy ${energy} TeV outside contract [${CONTRACT.energyTeV[0]}, ${CONTRACT.energyTeV[1]}] TeV`);
  if(errors.length) return {ok:false, code:'INVALID_INPUT', errors};
  return {ok:true, input:{seed, type, vertex:vertex.slice(), direction:unit, energy}};
}

/* UI path: draw a legal EventInput from (type, E, dirMode, seed). Same sampling formulas as RC0.5. */
export function sampleEventInput(type, E, dirMode, seed){
  const rng = mulberry32(seed);
  let cz;
  if(dirMode==='up') cz = -0.08 - rng()*0.92;
  else if(dirMode==='down') cz = 0.08 + rng()*0.92;
  else cz = rng()*2-1;
  const sz=Math.sqrt(1-cz*cz), ph=rng()*Math.PI*2;
  const direction=[-sz*Math.cos(ph), -cz, -sz*Math.sin(ph)];      // travel = −source
  const [rMax,dTop,dBot] = type==='through' ? [420,1600,2300] : (type==='starting' ? [380,1600,2300] : [400,1600,2300]);
  const r=rMax*Math.sqrt(rng()), a=rng()*Math.PI*2;
  const vertex=[r*Math.cos(a), -(dTop+rng()*(dBot-dTop)), r*Math.sin(a)];
  return {seed, type, vertex, direction, energy:E};
}

/* ---------------- B01: muon propagation with an energy ledger ---------------- */
// Continuous loss A_ION·ds plus a homogeneous Poisson process of resolved stochastic losses (rate STOCH_RATE),
// each removing a fraction v = min(0.5, Exp(0.06)) of the REMAINING energy. The muon stops when its energy is spent.
// Every subtraction is from remainingEnergy, so nothing can deposit energy that does not exist.
export function propagateMuon(p0, dir, s0, sMax, E0, R){
  let E=E0, s=s0, cont=0, stoch=0; const losses=[]; let stopped=false;
  while(true){
    const sNext = s + R.expo(1/STOCH_RATE);
    const sEnd = Math.min(sNext, sMax);
    const need = A_ION*(sEnd-s);
    if(need >= E){ s = s + E/A_ION; cont += E; E = 0; stopped = true; break; }
    E -= need; cont += need; s = sEnd;
    if(sNext >= sMax) break;
    const v = Math.min(STOCH_FRAC_MAX, R.expo(STOCH_FRAC_MEAN));
    const dE = v*E; E -= dE; stoch += dE;
    const pos=[p0[0]+dir[0]*s, p0[1]+dir[1]*s, p0[2]+dir[2]*s];
    losses.push({s, E:dE, pos, inIce:inIce(pos[1])});
  }
  const escaped = stopped ? 0 : E;
  return { sEnd:s, stopped, losses,
    ledger:{ initialEnergy:E0, remainingEnergy:E, continuousDepositedEnergy:cont, stochasticDepositedEnergy:stoch,
             escapedEnergy:escaped, totalDepositedEnergy:cont+stoch, residual:E0-(cont+stoch+escaped) } };
}

/* ---------------- geometry: direct Cherenkov arrival (verbatim RC0.5 formula) ---------------- */
export function trackDirect(D, p0, dir, s0, s1, idx){
  const tx=D.x-p0[0], ty=D.y-p0[1], tz=D.z-p0[2];
  const along = tx*dir[0] + ty*dir[1] + tz*dir[2];
  const perp2 = Math.max((tx*tx+ty*ty+tz*tz)-along*along,0);
  const d = Math.max(Math.sqrt(perp2),3);
  let se = along - d/idx.TAN_TC, path = d/idx.SIN_TC, scale = 1;
  if(se<s0 || se>s1){
    se = se<s0 ? s0 : s1;
    const ex=p0[0]+dir[0]*se, ey_=p0[1]+dir[1]*se, ez=p0[2]+dir[2]*se;
    const dx=ex-D.x, dy=ey_-D.y, dz=ez-D.z;
    path = Math.max(Math.sqrt(dx*dx+dy*dy+dz*dz),3); scale=0.3;
  }
  const ey = p0[1] + dir[1]*se;
  const t = (se-s0)/C + path/idx.V_LIGHT;
  return { along, dRaw:Math.sqrt(perp2), d, se, path, scale, ey, t };
}
export function indices(nPhase=DEFAULT_N_PHASE, nGroup=DEFAULT_N_GROUP){
  const COS_TC=1/nPhase, SIN_TC=Math.sqrt(1-COS_TC*COS_TC); return {N_PHASE:nPhase, N_GROUP:nGroup, COS_TC, SIN_TC, TAN_TC:SIN_TC/COS_TC, V_LIGHT:C/nGroup};
}

/* ---------------- B02: energy → light sources ---------------- */
// Three light components; every TeV of deposited energy is represented exactly once.
//   bare        : the muon's own Cherenkov light, B_TRACK per √m-geometry, emitted while the muon is alive and in ice.
//                 Not an energy deposit (photon energy is negligible); it does not scale with E.
//   continuous  : energy A_ION per metre deposited along the track → line source.
//                 Amplitude A_CASC·ε·√(2π·λ_eff): the asymptotic integral of the point-source law along a line
//                 (∫ A e^{-r/λ}/r ds ≈ A√(2πλ/d) e^{-d/λ}), so continuous and point deposits share one yield constant.
//   stochastic  : each resolved loss (and the hadronic/EM cascade of starting/cascade events) → isotropic point source,
//                 μ = A_CASC·E·e^{-τ}/r.
//   unresolved/subthreshold component: NOT MODELLED in RC0.6 (documented; contributes 0).
export function buildEvent(input, R){
  const {type, energy:E, vertex:q, direction:dir} = input;
  const ev = { input, type, dir, tracks:[], points:[], vertex:null, ledger:null };
  let had = 0;
  if(type==='through'){
    const p0=[q[0]-1700*dir[0], q[1]-1700*dir[1], q[2]-1700*dir[2]];
    const prop = propagateMuon(p0, dir, 0, 3400, E, R);
    ev.tracks.push({p0, s0:0, s1:prop.sEnd, sMax:3400, E0:E, stopped:prop.stopped});
    for(const l of prop.losses) if(l.inIce) ev.points.push({pos:l.pos, t:l.s/C, E:l.E, origin:'stochastic'});
    ev.muonLedger = prop.ledger; ev.center=q; ev.nuEnd=p0; ev.Emu=E;
    ev.ledger = eventLedger(E, 0, prop);
  } else if(type==='starting'){
    const y = 0.25 + R.rng()*0.35;
    had = E*y; const Emu = E*(1-y);
    ev.vertex=q; ev.points.push({pos:q.slice(), t:0, E:had, origin:'hadronic'});
    const prop = propagateMuon(q.slice(), dir, 0, 2600, Emu, R);
    ev.tracks.push({p0:q.slice(), s0:0, s1:prop.sEnd, sMax:2600, E0:Emu, stopped:prop.stopped});
    for(const l of prop.losses) if(l.inIce) ev.points.push({pos:l.pos, t:l.s/C, E:l.E, origin:'stochastic'});
    ev.muonLedger = prop.ledger; ev.center=q; ev.nuEnd=q.slice(); ev.Emu=Emu; ev.Ehad=had;
    ev.ledger = eventLedger(E, had, prop);
  } else {
    ev.vertex=q; ev.points.push({pos:q.slice(), t:0, E, origin:'cascade'});
    ev.center=q; ev.nuEnd=q.slice();
    ev.ledger = { initialEnergy:E, remainingEnergy:0, continuousDepositedEnergy:0, stochasticDepositedEnergy:0, cascadeDepositedEnergy:E, escapedEnergy:0, totalDepositedEnergy:E, residual:0 };
  }
  return ev;
}
function eventLedger(E, had, prop){
  const L=prop.ledger; const tot = had + L.continuousDepositedEnergy + L.stochasticDepositedEnergy;
  return { initialEnergy:E, remainingEnergy:L.remainingEnergy, continuousDepositedEnergy:L.continuousDepositedEnergy,
    stochasticDepositedEnergy:L.stochasticDepositedEnergy, cascadeDepositedEnergy:had, escapedEnergy:L.escapedEnergy,
    totalDepositedEnergy:tot, residual:E-(tot+L.escapedEnergy) };
}

/* expected light and direct time of every source at one DOM */
export function sourceTerms(D, ev, idx){
  const out=[];
  for(const tr of ev.tracks){
    const g = trackDirect(D, tr.p0, ev.dir, tr.s0, tr.s1, idx);
    if(!inIce(g.ey)) continue;
    const tau = opticalDepth(g.ey, D.y, g.path);
    const lamEff = tau>0 ? g.path/tau : 1e9;
    const amp = B_TRACK + A_CASC*A_ION*Math.sqrt(2*Math.PI*lamEff);
    const mu = g.scale*amp*Math.exp(-tau)/Math.sqrt(g.scale<1?g.path:g.d);
    out.push({kind:'track', mu, t:g.t, path:g.path});
  }
  for(const P of ev.points){
    const dx=D.x-P.pos[0], dy=D.y-P.pos[1], dz=D.z-P.pos[2];
    const r = Math.max(Math.sqrt(dx*dx+dy*dy+dz*dz),3);
    const mu = A_CASC*P.E*Math.exp(-opticalDepth(P.pos[1], D.y, r))/r;
    out.push({kind:P.origin, mu, t:P.t + r/idx.V_LIGHT, path:r});
  }
  return out;
}

/* ---------------- B03: per-source photon counting and first-photon composition ---------------- */
// Each source i contributes n_i ~ Poisson(μ_i) photoelectrons (independent Poisson processes ⇒ the total is
// Poisson(Σμ) whatever the partition). Each photon from source i arrives at t_i + δ, δ ~ Weibull(k=1/0.7, λ_i),
// λ_i = 0.8·path_i/Γ(1.7). The first of n_i photons is Weibull(k, λ_i·n_i^{-0.7}), whose mean 0.8·path_i/n_i^{0.7}
// reproduces the RC0.5 delay law. The DOM's physical first-photon time is the minimum over sources; its
// measured time adds electronics jitter. The result is invariant (in distribution) under splitting or merging
// co-located, co-timed sources.
export function domResponse(terms, R, opts){
  let n=0, tPhys=Infinity, tDirect=Infinity, muTot=0;
  for(const s of terms){
    muTot += s.mu; if(s.t<tDirect && s.mu>MU_MIN) tDirect=s.t;
    if(!(s.mu>MU_MIN)) continue;
    const k = R.poisson(s.mu); if(k<1) continue;
    n += k;
    let delay = 0;
    if(opts.scatter){ const scale = DELAY_COEF*s.path/GAMMA_1P7*Math.pow(k,-DELAY_EXP); delay = scale*Math.pow(-Math.log(1-R.rng()), DELAY_EXP); }
    const tf = s.t + delay; if(tf<tPhys) tPhys=tf;
  }
  if(n<1) return null;
  const q = Math.max(0.3, n*(1+0.25*R.gauss()/Math.sqrt(n)));
  const tMeas = tPhys + (opts.jitter ? JITTER_NS*R.gauss() : 0);
  return { n, q, tPhys, t:tMeas, mu:muTot, tDirect };
}

/* ---------------- event simulation (validated entry point) ---------------- */
export function simulateEvent(rawInput, options={}){
  const v = validateEventInput(rawInput);
  if(!v.ok) return { status:'INVALID_INPUT', errors:v.errors };
  const opts = { nPhase:DEFAULT_N_PHASE, nGroup:DEFAULT_N_GROUP, noise:true, scatter:true, jitter:true, record:false, ...options };
  const idx = indices(opts.nPhase, opts.nGroup);
  const R = makeRandom(mulberry32((v.input.seed ^ 0x5bd1e995)>>>0));
  const ev = buildEvent(v.input, R);
  const hits=[]; const records = opts.record ? [] : null;
  for(const D of doms){
    const terms = sourceTerms(D, ev, idx);
    if(records) records.push({dom:D.idx, terms});
    const h = domResponse(terms, R, opts);
    if(h) hits.push({dom:D.idx, ...h, noise:false});
  }
  let tmin=Infinity,tmax=-Infinity; for(const h of hits){tmin=Math.min(tmin,h.t);tmax=Math.max(tmax,h.t);}
  if(!hits.length){tmin=0;tmax=3000;}
  const w0=tmin-800, w1=tmax+500;
  if(opts.noise){
    const nNoise = R.poisson(doms.length*DARK_RATE_PER_NS*(w1-w0));
    const used = new Set(hits.map(h=>h.dom));
    for(let i=0;i<nNoise;i++){ const di=Math.floor(R.rng()*doms.length); if(used.has(di)) continue; used.add(di); hits.push({dom:di,t:w0+R.rng()*(w1-w0),tPhys:null,q:0.4+R.rng()*0.9,n:0,noise:true}); }
  }
  // HLC-like cleaning (unchanged): neighbour within 2 DOMs on the same string, |dt| < 1 µs
  const byDom = new Map(hits.map(h=>[h.dom,h]));
  for(const h of hits){
    const D=doms[h.dom], arr=domsByString.get(D.str); h.clean=false;
    for(let k=-2;k<=2;k++){ if(!k) continue; const j=D.om-1+k; if(j<0||j>=arr.length) continue; const o=byDom.get(arr[j]); if(o && Math.abs(o.t-h.t)<1000){h.clean=true;break;} }
  }
  const clean = hits.filter(h=>h.clean);
  const reco = reconstruct(clean.map(h=>({...doms[h.dom], t:h.t, q:h.q})));
  return { status:'OK', version:VERSION, input:v.input, event:ev, ledger:ev.ledger, hits, clean, byDom, reco, records, options:opts };
}

/* ---------------- B06: reconstruction with validity tiers ---------------- */
export const RECO_GATES = { minHitsComputed:4, minTimeVar_ns2:1, identifiable:{minStrings:3, minTimeSpan_ns:30, minThirdAxis_m:5},
  usable:{minHits:8, minStrings:3, minElongation:1.5, minStCorrelation:0.8, speedRange_m_per_ns:[0.05,0.6]} };
// minStCorrelation (signal-quality indicator) was chosen from a simulated sample (seeds 90001–90300) disjoint from the test seeds; see RECONSTRUCTION_VALIDITY.md.
function symEig3(m){ // Jacobi eigenvalues of a symmetric 3×3 matrix, descending
  const a=[[m[0][0],m[0][1],m[0][2]],[m[1][0],m[1][1],m[1][2]],[m[2][0],m[2][1],m[2][2]]];
  for(let it=0; it<50; it++){
    let p=0,q=1,max=Math.abs(a[0][1]);
    if(Math.abs(a[0][2])>max){p=0;q=2;max=Math.abs(a[0][2]);} if(Math.abs(a[1][2])>max){p=1;q=2;max=Math.abs(a[1][2]);}
    if(max<1e-12) break;
    const th=0.5*Math.atan2(2*a[p][q], a[q][q]-a[p][p]); const c=Math.cos(th), s=Math.sin(th);
    for(let k=0;k<3;k++){ const akp=a[k][p], akq=a[k][q]; a[k][p]=c*akp-s*akq; a[k][q]=s*akp+c*akq; }
    for(let k=0;k<3;k++){ const apk=a[p][k], aqk=a[q][k]; a[p][k]=c*apk-s*aqk; a[q][k]=s*apk+c*aqk; }
  }
  return [a[0][0],a[1][1],a[2][2]].sort((x,y)=>y-x);
}
// hits: [{x,y,z,t,q,str}]. Returns tiers; never uses truth.
export function reconstruct(hits){
  const G=RECO_GATES; const res={ status:'NOT_COMPUTED', computed:false, identifiable:false, usable:false, reasons:[], metrics:{N:hits.length}, dir:null, speed:null, pos:null, cog:null, cogValid:false };
  const N=hits.length;
  if(N>=1 && hits.every(h=>[h.x,h.y,h.z,h.q].every(Number.isFinite))){
    let qs=0; const cog=[0,0,0]; for(const h of hits){cog[0]+=h.x*h.q;cog[1]+=h.y*h.q;cog[2]+=h.z*h.q;qs+=h.q;}
    if(qs>0){ res.cog=cog.map(v=>v/qs); res.cogValid = N>=4 && new Set(hits.map(h=>h.str)).size>=2; }
  }
  if(N<G.minHitsComputed){ res.reasons.push(`N=${N} < ${G.minHitsComputed}`); return res; }
  if(!hits.every(h=>[h.x,h.y,h.z,h.t].every(Number.isFinite))){ res.reasons.push('non-finite hit values'); return res; }
  let tb=0; const rb=[0,0,0]; for(const h of hits){rb[0]+=h.x;rb[1]+=h.y;rb[2]+=h.z;tb+=h.t;} rb.forEach((v,i)=>rb[i]=v/N); tb/=N;
  let tt=0; const rt=[0,0,0]; for(const h of hits){rt[0]+=h.x*h.t;rt[1]+=h.y*h.t;rt[2]+=h.z*h.t;tt+=h.t*h.t;} rt.forEach((v,i)=>rt[i]=v/N); tt/=N;
  const varT = tt-tb*tb;
  if(!(varT>G.minTimeVar_ns2)){ res.reasons.push(`time variance ${varT.toExponential(2)} ns² ≤ ${G.minTimeVar_ns2}`); return res; }
  const v=rt.map((x,i)=>(x-rb[i]*tb)/varT); const speed=Math.hypot(...v);
  if(!Number.isFinite(speed) || speed<1e-9){ res.reasons.push('degenerate velocity'); return res; }
  res.computed=true; res.status='COMPUTED'; res.dir=v.map(x=>x/speed); res.speed=speed; res.pos=rb;
  // geometry / conditioning metrics (data only)
  const cov=[[0,0,0],[0,0,0],[0,0,0]]; const P=hits.map(h=>[h.x-rb[0],h.y-rb[1],h.z-rb[2]]);
  for(const p of P) for(let i=0;i<3;i++) for(let j=0;j<3;j++) cov[i][j]+=p[i]*p[j]/N;
  const ev=symEig3(cov).map(x=>Math.max(x,0)); const ax=ev.map(Math.sqrt);
  const ts=hits.map(h=>h.t); const span=Math.max(...ts)-Math.min(...ts); const nStr=new Set(hits.map(h=>h.str)).size;
  // signal-quality indicator: correlation between position along the fitted direction and hit time
  let cs=0,vs=0,vt=0; for(let i=0;i<N;i++){ const sp=P[i][0]*res.dir[0]+P[i][1]*res.dir[1]+P[i][2]*res.dir[2]; const dt=hits[i].t-tb; cs+=sp*dt; vs+=sp*sp; vt+=dt*dt; }
  const stCorr = (vs>0&&vt>0) ? cs/Math.sqrt(vs*vt) : 0;
  Object.assign(res.metrics,{nStrings:nStr, timeSpan_ns:span, axes_m:ax, elongation: ax[1]>0 ? ax[0]/ax[1] : Infinity, stCorrelation:stCorr, speed_m_per_ns:speed});
  const I=G.identifiable, U=G.usable;
  if(nStr<I.minStrings) res.reasons.push(`strings=${nStr} < ${I.minStrings}`);
  if(span<I.minTimeSpan_ns) res.reasons.push(`time span ${span.toFixed(1)} ns < ${I.minTimeSpan_ns}`);
  if(ax[2]<I.minThirdAxis_m) res.reasons.push(`hit cloud is not 3-D (third axis ${ax[2].toFixed(1)} m < ${I.minThirdAxis_m})`);
  res.identifiable = nStr>=I.minStrings && span>=I.minTimeSpan_ns && ax[2]>=I.minThirdAxis_m;
  if(!res.identifiable) return res;
  res.status='IDENTIFIABLE';
  if(N<U.minHits) res.reasons.push(`N=${N} < ${U.minHits}`);
  if(res.metrics.elongation<U.minElongation) res.reasons.push(`not track-like (elongation ${res.metrics.elongation.toFixed(2)} < ${U.minElongation})`);
  if(stCorr<U.minStCorrelation) res.reasons.push(`weak position–time correlation ${stCorr.toFixed(2)} < ${U.minStCorrelation}`);
  if(speed<U.speedRange_m_per_ns[0] || speed>U.speedRange_m_per_ns[1]) res.reasons.push(`fit speed ${speed.toFixed(3)} m/ns outside [${U.speedRange_m_per_ns}] (fit-quality flag, not a particle speed)`);
  res.usable = N>=U.minHits && res.metrics.elongation>=U.minElongation && stCorr>=U.minStCorrelation && speed>=U.speedRange_m_per_ns[0] && speed<=U.speedRange_m_per_ns[1];
  if(res.usable) res.status='USABLE';
  return res;
}
// Simulated-QA only: truth is never used by reconstruct().
export function qaAngularError(dir, truth){
  if(!dir) return null; const d=dir[0]*truth[0]+dir[1]*truth[1]+dir[2]*truth[2];
  return Math.acos(Math.max(-1,Math.min(1,d)))*180/Math.PI;
}
export const _internal = { makeRandom, GAMMA_1P7, cumInv, LAYERS };
