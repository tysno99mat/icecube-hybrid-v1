import * as THREE from '../../../node_modules/three/build/three.module.js';
export const CFG = {poisson:true, scatter:true, jitter:true, noise:true, stochLosses:true, record:false};
/* ---------- physics constants ---------- */
const C = 0.299792458;            // m/ns
let N_PHASE = 1.32, N_GROUP = 1.35;
let COS_TC = 1 / N_PHASE, SIN_TC = Math.sqrt(1 - COS_TC * COS_TC), TAN_TC = SIN_TC / COS_TC;
let V_LIGHT = C / N_GROUP;
export function setIndices(np, ng){ N_PHASE=np; N_GROUP=ng; COS_TC=1/N_PHASE; SIN_TC=Math.sqrt(1-COS_TC*COS_TC); TAN_TC=SIN_TC/COS_TC; V_LIGHT=C/N_GROUP; }
export const getIndices = () => ({N_PHASE, N_GROUP, COS_TC, SIN_TC, TAN_TC, V_LIGHT});      // photon group speed in ice
const BEDROCK = 2820;
const NS_PER_SEC = 500;

/* ---------- RNG ---------- */
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}}
let rng = mulberry32(1);
function gauss(){let u=0;while(!u)u=rng();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*rng());}
function poisson(mu){ if(mu<=0) return 0; if(mu>30) return Math.max(0,Math.round(mu+Math.sqrt(mu)*gauss())); const L=Math.exp(-mu); let k=0,p=1; do{k++;p*=rng();}while(p>L); return k-1; }
const expo = m => -m*Math.log(1-rng());

/* ---------- detector geometry ---------- */
function linspace(a,b,n){const o=[];for(let i=0;i<n;i++)o.push(a+(b-a)*i/(n-1));return o;}
const strings = [];
{
  const S = 125, pts = [];
  for(let q=-6;q<=6;q++) for(let r=-6;r<=6;r++){
    const hd=(Math.abs(q)+Math.abs(r)+Math.abs(q+r))/2; if(hd>5) continue;
    const x=S*(q+r/2), z=S*(r*Math.sqrt(3)/2);
    pts.push({x,z,d:Math.hypot(x*0.9,z*1.12)});
  }
  pts.sort((a,b)=>a.d-b.d);
  const std = pts.slice(0,78).sort((a,b)=>(a.z-b.z)||(a.x-b.x));
  std.forEach((p,i)=>strings.push({id:i+1,x:p.x,z:p.z,deep:false}));
  const dc=[];
  for(let k=0;k<6;k++){const a=Math.PI/6+k*Math.PI/3; dc.push([72*Math.cos(a),72*Math.sin(a)]);}
  dc.push([144*Math.cos(Math.PI/6),144*Math.sin(Math.PI/6)]);
  dc.push([144*Math.cos(7*Math.PI/6),144*Math.sin(7*Math.PI/6)]);
  dc.forEach((p,i)=>strings.push({id:79+i,x:p[0],z:p[1],deep:true}));
}
const STD_DEPTHS = linspace(1450,2450,60);
const DC_DEPTHS = [...linspace(1750,1850,10), ...linspace(2100,2450,50)];
const doms = [];
const domsByString = new Map();
for(const s of strings){
  const arr=[]; (s.deep?DC_DEPTHS:STD_DEPTHS).forEach((d,i)=>{ const idx=doms.length; doms.push({idx,str:s.id,om:i+1,x:s.x,y:-d,z:s.z,depth:d}); arr.push(idx); });
  domsByString.set(s.id,arr);
}

/* ---------- ice optics (illustrative) ---------- */
function invLambda(depth){
  if(depth<0) return 1;
  if(depth<1400) return 1/10;     // bubbles
  if(depth<2000) return 1/42;
  if(depth<2100) return 1/16;     // dust layer
  if(depth<2450) return 1/70;     // clearest ice
  if(depth<BEDROCK) return 1/60;
  return 1;
}
function avgInvL(y1,y2){ const d1=-y1,d2=-y2; return (invLambda(d1)+invLambda((d1+d2)/2)+invLambda(d2))/3; }
const inIce = y => y<0 && y>-BEDROCK;

/* ---------- event generation & detector response ---------- */
const A_CASC = 220, B_TRACK = 17;
const DET_C = new THREE.Vector3(0,-1950,0);

function sampleDirection(mode){
  let cz;
  if(mode==='up') cz = -0.08 - rng()*0.92;
  else if(mode==='down') cz = 0.08 + rng()*0.92;
  else cz = rng()*2-1;
  const sz=Math.sqrt(1-cz*cz), ph=rng()*Math.PI*2;
  const src = new THREE.Vector3(sz*Math.cos(ph), cz, sz*Math.sin(ph)); // where it comes from
  return src.clone().negate();                                        // travel direction
}
function randomInside(rMax, dTop, dBot){
  const r=rMax*Math.sqrt(rng()), a=rng()*Math.PI*2;
  return new THREE.Vector3(r*Math.cos(a), -(dTop+rng()*(dBot-dTop)), r*Math.sin(a));
}

function makeEvent(type, E, dirMode, seed, ov=null){
  rng = mulberry32(seed);
  const dir = ov?.dir ? ov.dir.clone() : sampleDirection(dirMode);
  const ev = {type, E, dir, seed, tracks:[], points:[], vertex:null};
  if(type==='through'){
    const q = ov?.vertex ? ov.vertex.clone() : randomInside(420,1600,2300);
    const p0 = q.clone().addScaledVector(dir,-(ov?.back ?? 1700));
    ev.tracks.push({p0, s0:0, s1:(ov?.len ?? 3400), E});
    ev.nuEnd = p0.clone();
    ev.center = q;
    ev.Emu = E;
  } else if(type==='starting'){
    const q = ov?.vertex ? ov.vertex.clone() : randomInside(380,1600,2300);
    const y = 0.25 + rng()*0.35;
    ev.vertex = q;
    ev.points.push({pos:q.clone(), t:0, E:E*y, main:true});
    ev.tracks.push({p0:q.clone(), s0:0, s1:(ov?.len ?? 2600), E:E*(1-y)});
    ev.nuEnd = q.clone(); ev.center=q; ev.Emu=E*(1-y); ev.Ehad=E*y;
  } else {
    const q = ov?.vertex ? ov.vertex.clone() : randomInside(400,1600,2300);
    ev.vertex = q;
    ev.points.push({pos:q.clone(), t:0, E, main:true});
    ev.nuEnd = q.clone(); ev.center=q;
  }
  // stochastic energy losses along muon tracks
  for(const tr of (CFG.stochLosses ? ev.tracks : [])){
    const L = (tr.s1-tr.s0)/1000;
    const k = poisson(L*4);
    for(let i=0;i<k;i++){
      const s = tr.s0 + rng()*(tr.s1-tr.s0);
      const pos = tr.p0.clone().addScaledVector(ev.dir,s);
      if(!inIce(pos.y)) continue;
      ev.points.push({pos, t:(s-tr.s0)/C, E:tr.E*Math.min(0.5,expo(0.06)), main:false});
    }
  }
  simulateResponse(ev);
  return ev;
}

function simulateResponse(ev){
  const hits=[]; const tmp=new THREE.Vector3();
  for(const D of doms){
    let mu=0, tDir=Infinity, dDom=0, best=0;
    const rec = CFG.record ? {dom:D.idx, tracks:[], points:[]} : null; // [audit log]
    for(const tr of ev.tracks){
      tmp.set(D.x-tr.p0.x, D.y-tr.p0.y, D.z-tr.p0.z);
      const along = tmp.dot(ev.dir);
      const perp2 = Math.max(tmp.lengthSq()-along*along,0);
      const d = Math.max(Math.sqrt(perp2),3);
      let se = along - d/TAN_TC, path = d/SIN_TC, scale = 1;
      if(se<tr.s0 || se>tr.s1){ // outside segment: scattered light from nearest end
        se = se<tr.s0 ? tr.s0 : tr.s1;
        const e = tr.p0.clone().addScaledVector(ev.dir,se);
        path = Math.max(e.distanceTo(new THREE.Vector3(D.x,D.y,D.z)),3); scale=0.3;
      }
      const ey = tr.p0.y + ev.dir.y*se;
      if(rec) rec.tracks.push({along, dRaw:Math.sqrt(perp2), d, se, path, scale, ey, inIce:inIce(ey)}); // [audit log]
      if(!inIce(ey)) continue;
      const m = scale*B_TRACK*(1+0.3*tr.E)*Math.exp(-path*avgInvL(ey,D.y))/Math.sqrt(scale<1?path:d);
      const t = (se-tr.s0)/C + path/V_LIGHT;
      if(rec){ const r=rec.tracks[rec.tracks.length-1]; r.m=m; r.t=t; } // [audit log]
      mu += m; if(m>0.02 && t<tDir) tDir=t; if(m>best){best=m; dDom=path;}
    }
    for(const P of ev.points){
      const r = Math.max(Math.hypot(D.x-P.pos.x,D.y-P.pos.y,D.z-P.pos.z),3);
      const m = A_CASC*P.E*Math.exp(-r*avgInvL(P.pos.y,D.y))/r;
      const t = P.t + r/V_LIGHT;
      if(rec) rec.points.push({r, m, t, main:!!P.main}); // [audit log]
      mu += m; if(m>0.02 && t<tDir) tDir=t; if(m>best){best=m; dDom=r;}
    }
    if(rec){ rec.mu=mu; rec.tDir=tDir; rec.dDom=dDom; (ev.records ||= []).push(rec); } // [audit log]
    if(mu<1e-4 || !isFinite(tDir)) continue;
    const n = CFG.poisson ? poisson(mu) : Math.round(mu);
    if(n<1) continue;
    const q = Math.max(0.3, n*(1+0.25*gauss()/Math.sqrt(n)));
    const delay = CFG.scatter ? expo(0.8*dDom/Math.pow(n,0.7)) : 0;
    hits.push({dom:D.idx, t:tDir+delay+(CFG.jitter?2*gauss():0), q, noise:false, tDir, mu, delay});
  }
  // dark-count noise (~500 Hz per DOM)
  let tmin=Infinity,tmax=-Infinity; for(const h of hits){tmin=Math.min(tmin,h.t);tmax=Math.max(tmax,h.t);}
  if(!hits.length){tmin=0;tmax=3000;}
  const w0=tmin-800, w1=tmax+500;
  const nNoise = CFG.noise ? poisson(doms.length*5e-7*(w1-w0)) : 0;
  const used = new Set(hits.map(h=>h.dom));
  for(let i=0;i<nNoise;i++){ const di=Math.floor(rng()*doms.length); if(used.has(di)) continue; used.add(di); hits.push({dom:di,t:w0+rng()*(w1-w0),q:0.4+rng()*0.9,noise:true}); }
  // HLC-like cleaning: neighbour within 2 DOMs on same string, |dt| < 1 µs
  const byDom = new Map(hits.map(h=>[h.dom,h]));
  for(const h of hits){
    const D=doms[h.dom], arr=domsByString.get(D.str); h.clean=false;
    for(let k=-2;k<=2;k++){ if(!k) continue; const j=D.om-1+k; if(j<0||j>=arr.length) continue; const o=byDom.get(arr[j]); if(o && Math.abs(o.t-h.t)<1000){h.clean=true;break;} }
  }
  ev.hits = hits; ev.byDom = byDom;
  const phys = hits.filter(h=>!h.noise && h.clean).sort((a,b)=>a.t-b.t);
  ev.clean = hits.filter(h=>h.clean);
  ev.phys = phys;
  const ts = phys.map(h=>h.t);
  ev.cMin = ts.length?ts[0]:0;
  ev.cMax = ts.length?ts[Math.floor((ts.length-1)*0.9)]:1;
  if(ev.cMax-ev.cMin<50) ev.cMax=ev.cMin+50;
  ev.lastHit = ts.length?ts[ts.length-1]:0;
  ev.tStart = ev.type==='through' ? (ts.length?ts[0]-700:0) : -900;
  ev.tEnd = (ts.length?ev.lastHit:1500)+400;
  reconstruct(ev);
}

function reconstruct(ev){
  const H = ev.clean;
  ev.reco=null; if(H.length<4) return;
  const N=H.length; let tb=0; const rb=new THREE.Vector3();
  for(const h of H){const D=doms[h.dom]; rb.x+=D.x; rb.y+=D.y; rb.z+=D.z; tb+=h.t;}
  rb.divideScalar(N); tb/=N;
  const rt=new THREE.Vector3(); let tt=0;
  for(const h of H){const D=doms[h.dom]; rt.x+=D.x*h.t; rt.y+=D.y*h.t; rt.z+=D.z*h.t; tt+=h.t*h.t;}
  rt.divideScalar(N); tt/=N;
  const v = rt.sub(rb.clone().multiplyScalar(tb)).divideScalar(Math.max(tt-tb*tb,1e-6));
  const speed = v.length(); const dir = v.clone().normalize();
  const ang = THREE.MathUtils.radToDeg(Math.acos(THREE.MathUtils.clamp(dir.dot(ev.dir),-1,1)));
  // charge-weighted centre of gravity (cascade vertex estimate)
  const cog=new THREE.Vector3(); let qs=0;
  for(const h of H){const D=doms[h.dom]; cog.x+=D.x*h.q; cog.y+=D.y*h.q; cog.z+=D.z*h.q; qs+=h.q;}
  cog.divideScalar(qs);
  ev.reco = {pos:rb, dir, speed, ang, cog, vErr: ev.vertex? cog.distanceTo(ev.vertex):null};
}


export { strings, doms, domsByString, makeEvent, simulateResponse, reconstruct, invLambda, avgInvL, inIce, C, A_CASC, B_TRACK, BEDROCK, mulberry32 };
