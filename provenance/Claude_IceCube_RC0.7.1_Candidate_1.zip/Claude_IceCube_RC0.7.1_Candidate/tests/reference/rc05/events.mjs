// Common EventInput contract + deterministic event sets for RC0.5.
// Frame: Claude frame (metres; x,z horizontal; y = -depth; surface y = 0).
// GPT frame differs only by a vertical offset: y_gpt = y + 1950 (GPT puts y = 0 at 1950 m depth).
import { mulberry32 } from './claude_core_rc05.mjs';

export const GPT_Y_OFFSET = 1950;
const norm = v => { const l = Math.hypot(...v); return v.map(x => x / l); };

function dirFromZenith(rng, zMinDeg, zMaxDeg) {
  // zenith of the SOURCE direction; travel direction = -source
  const cz = Math.cos(zMinDeg * Math.PI / 180) - rng() * (Math.cos(zMinDeg * Math.PI / 180) - Math.cos(zMaxDeg * Math.PI / 180));
  const sz = Math.sqrt(1 - cz * cz), ph = rng() * 2 * Math.PI;
  return [-sz * Math.cos(ph), -cz, -sz * Math.sin(ph)];
}
function vertexInside(rng, rMax, dTop, dBot) {
  const r = rMax * Math.sqrt(rng()), a = rng() * 2 * Math.PI;
  return [r * Math.cos(a), -(dTop + rng() * (dBot - dTop)), r * Math.sin(a)];
}
const logU = (rng, a, b) => Math.pow(10, Math.log10(a) + rng() * (Math.log10(b) - Math.log10(a)));
const r4 = v => v.map(x => +x.toFixed(4));
// Contract rule (added after run 1): directions are stored as exact unit vectors.
const unit = v => norm(v);

// Common track segment (used identically by both models in Phase 2):
//   through : start = vertex - 1700*dir, length 3400   (Claude native defaults)
//   starting: start = vertex,            length 2600   (Claude native default)
//   GPT-REF : start = GPT origin,        length 1040   (GPT native defaults)
export function segmentOf(e) {
  if (e.type === 'through') return { start: e.vertex.map((v, i) => v - 1700 * e.direction[i]), length: 3400, back: 1700 };
  if (e.type === 'starting') return { start: e.vertex.slice(), length: e.trackLength ?? 2600, back: 0 };
  return null; // cascade: no track
}

export function fixedEvents() {
  const rng = mulberry32(20261007);
  const ev = [];
  // E00: GPT's own hard-coded event, expressed in the common frame.
  ev.push({ id: 'E00-GPTREF', seed: 1000, type: 'starting', vertex: [-410, 175 - GPT_Y_OFFSET, 110], direction: unit([1, -0.34, -0.22]), energy: 0.33, trackLength: 1040,
            note: "GPT native event: origin [-410,175,110] (GPT frame), d=norm(1,-0.34,-0.22), L=1040 m. Energy not defined by GPT; 0.33 TeV is the muon energy whose range is ~1 km (harness assumption)." });
  for (let i = 0; i < 12; i++) {
    let direction;
    if (i === 10) direction = [0, -1, 0];            // vertical down-going (degenerate-axis test)
    else if (i === 11) direction = unit([1, 0, 0.3]); // exactly horizontal
    else direction = unit(i < 5 ? dirFromZenith(rng, 95, 178) : dirFromZenith(rng, 2, 85));
    ev.push({ id: `T${String(i + 1).padStart(2, '0')}`, seed: 1001 + i, type: 'through', vertex: r4(vertexInside(rng, 420, 1600, 2300)), direction, energy: +logU(rng, 3, 1000).toFixed(2) });
  }
  for (let i = 0; i < 4; i++) ev.push({ id: `S${13 + i}`, seed: 1013 + i, type: 'starting', vertex: r4(vertexInside(rng, 380, 1600, 2300)), direction: unit(dirFromZenith(rng, 2, 178)), energy: +logU(rng, 10, 1000).toFixed(2) });
  for (let i = 0; i < 4; i++) ev.push({ id: `C${17 + i}`, seed: 1017 + i, type: 'cascade', vertex: r4(vertexInside(rng, 400, 1600, 2300)), direction: unit(dirFromZenith(rng, 2, 178)), energy: +logU(rng, 10, 3000).toFixed(2) });
  return ev;
}

export function recoTrackEvents(N = 100) {
  const out = [];
  for (let i = 0; i < N; i++) {
    const rng = mulberry32(50500 + i);
    const up = rng() < 0.5;
    out.push({ id: `R${String(i).padStart(3, '0')}`, seed: 50500 + i, type: 'through', vertex: r4(vertexInside(rng, 420, 1600, 2300)),
               direction: unit(up ? dirFromZenith(rng, 92, 178) : dirFromZenith(rng, 2, 88)), energy: +logU(rng, 3, 1000).toFixed(2) });
  }
  return out;
}
export function recoCascadeEvents(N = 50) {
  const out = [];
  for (let i = 0; i < N; i++) {
    const rng = mulberry32(70700 + i);
    out.push({ id: `RC${String(i).padStart(3, '0')}`, seed: 70700 + i, type: 'cascade', vertex: r4(vertexInside(rng, 400, 1600, 2300)),
               direction: unit(dirFromZenith(rng, 2, 178)), energy: +logU(rng, 10, 3000).toFixed(2) });
  }
  return out;
}
