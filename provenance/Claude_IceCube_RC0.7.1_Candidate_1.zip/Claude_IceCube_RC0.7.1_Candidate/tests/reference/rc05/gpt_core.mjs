export function gptModel(P = {}) {
  const c = 299.792458; // metres per microsecond
  const n = P.n ?? 1.32; // illustrative constant phase/group index; no dispersion model
  const theta = Math.acos(1 / n);
  const L = P.L ?? 1040;
  const origin = P.origin ?? [-410, 175, 110];
  const normalize = a => { const len=Math.hypot(...a); return a.map(v=>v/len); };
  const d = normalize(P.d ?? [1, -0.34, -0.22]);
  const u = normalize([-d[2], 0, d[0]]);
  const cross = (a,b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
  const v = cross(d,u);
  const add = (a,b,s=1) => a.map((x,i)=>x+b[i]*s);
  const dot = (a,b) => a.reduce((sum,x,i)=>sum+x*b[i],0);
  const clamp = (x,a,b) => Math.max(a,Math.min(b,x));

  // 78 illustrative hex-grid strings plus 8 denser DeepCore strings.
  // This preserves the original array count, not surveyed DOM coordinates.
  const candidates=[];
  for (let r=-7;r<=7;r++) for (let q=-7;q<=7;q++) {
    const x=125*(q+r/2), z=125*Math.sqrt(3)/2*r;
    if(Math.hypot(x,z)>84) candidates.push({x,z,radius:Math.hypot(x,z)});
  }
  candidates.sort((a,b)=>a.radius-b.radius || a.z-b.z || a.x-b.x);
  const strings=candidates.slice(0,78).map(p=>({x:p.x,z:p.z,core:false}));
  strings.push({x:0,z:0,core:true});
  for(let i=0;i<7;i++) strings.push({x:70*Math.cos(i*2*Math.PI/7),z:70*Math.sin(i*2*Math.PI/7),core:true});
  const sensors=[];
  const native=[]; strings.forEach((s,si)=>{ for(let k=0;k<60;k++){ const depth=s.core ? (k<10 ? 1450+k*10 : 2100+(k-10)*7) : 1450+k*(1000/59); native.push({si,k,depth,p:[s.x,1950-depth,s.z],core:s.core}); } }); // [audit] native geometry, same depth formula
  (P.geometry ?? native).forEach(G=> { const s={core:G.core}, si=G.si, k=G.k; {
      // DeepCore upper 10 DOMs act as a veto; lower 50 form the denser section.
      const depth=G.depth;
      const p=G.p.slice();
      const rel=p.map((x,i)=>x-origin[i]), parallel=dot(rel,d);
      const transverse=Math.sqrt(Math.max(0,dot(rel,rel)-parallel*parallel));
      const emission=parallel-transverse/Math.sqrt(n*n-1);
      const emissionPoint=add(origin,d,emission);
      const distance=Math.hypot(...p.map((x,i)=>x-emissionPoint[i]));
      const arrival=emission>=0 && emission<=L ? emission/c+n*distance/c : Infinity;
      // A fixed illustrative visibility radius, not measured photon yield.
      sensors.push({p,si,k,depth,arrival,emission,distance,hit:Number.isFinite(arrival)&&distance<240, transverse, emissionPoint, id:G.id});
    }
  });
  const pulseCount=sensors.filter(s=>s.hit).length;
  return { sensors, strings, native, pulseCount, n, theta, L, origin, d, c };
}
