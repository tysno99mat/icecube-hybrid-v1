// Runtime first-contact text check (G16 runtime part). Needs Playwright + Chromium (not part of the offline replay).
// Usage: node tests/ui_runtime_check.mjs <path-to-playwright/index.mjs>
import fs from 'fs';
const { chromium } = await import(process.argv[2]);
const ROOT = new URL('..', import.meta.url).pathname;
const BAN = ['重建方向', '可信方向', '方向可用', '有徑跡可抓方向', '方向通過可信度檢查', '可靠方向', '真實來向', '真實路徑', 'USABLE'];
const LEGEND = '圖例：黃色實線＝模擬真值路徑；青色虛線＋箭頭＝候選 LineFit';
const DISC = 'LineFit 是簡化的初步重建，只作示意；可能失敗，甚至反向。內部數值／幾何檢查不證明方向正確。擬合斜率是回歸參數，不是粒子或光子的速度。';
const b = await chromium.launch(); const out = { source: 'headless Chromium (Playwright), ' + new Date().toISOString(), variants: [] };
for (const variant of ['dist/offline/index.html', 'dist/icecube_rc071.html']) {
  for (const [vw, vh] of [[1400, 860], [400, 860]]) {
    const p = await b.newPage({ viewport: { width: vw, height: vh } });
    await p.route('**/*', async r => { const u = r.request().url(); const m = u.match(/cdn\.jsdelivr\.net\/npm\/three@0\.160\.0\/(.*)$/); if (m) return r.fulfill({ path: ROOT + 'node_modules/three/' + m[1], contentType: 'application/javascript' }); if (u.startsWith('file:') || u.startsWith('data:')) return r.continue(); return r.abort(); });
    const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.goto('file://' + ROOT + variant); await p.waitForTimeout(1500);
    const cases = [];
    for (const [btn, type] of [[null, 'through'], ['#tyStart', 'starting'], ['#tyCascade', 'cascade'], ['#tyThrough', 'through']]) {
      if (btn) { await p.click(btn); await p.click('#genBtn'); await p.waitForTimeout(200); }
      // start of the event: no LineFit line yet → disclosure must be hidden
      await p.evaluate(() => { const s = document.getElementById('tSl'); s.value = 0; s.dispatchEvent(new Event('input')); }); await p.waitForTimeout(150);
      const atStart = await p.evaluate(() => document.getElementById('lfDisclose').hidden);
      await p.evaluate(() => { const s = document.getElementById('tSl'); s.value = 1000; s.dispatchEvent(new Event('input')); }); await p.waitForTimeout(250);
      const st = await p.evaluate(() => { const d = document.getElementById('lfDisclose'); const r = d.getBoundingClientRect(); const vp = document.getElementById('viewport').getBoundingClientRect();
        return { text: document.body.innerText, step5: document.getElementById('step5Title').textContent, checkbox: document.getElementById('tgRecoLabel').textContent, disclosureHidden: d.hidden,
          disclosureInViewport: !d.hidden && r.width > 0 && r.top >= vp.top && r.bottom <= vp.bottom && r.left >= vp.left && r.right <= vp.right, disclosureText: document.getElementById('lfDiscloseText').textContent, legendText: document.getElementById('lfLegend').textContent, stReco: document.getElementById('stReco').innerText }; });
      const banned = BAN.filter(w => st.text.includes(w));
      const expectTrack = type !== 'cascade';
      const ok = !banned.length && st.step5 === (expectTrack ? '⑤ 方向重建示意' : '⑤ 頂點與光分布') && st.checkbox === (expectTrack ? '顯示 LineFit 示意（可能失敗／反向）' : '顯示電荷重心示意')
        && (expectTrack ? (st.disclosureInViewport && st.disclosureText === DISC && st.legendText === LEGEND && atStart === true) : st.disclosureHidden);
      cases.push({ type, ok, banned, step5: st.step5, checkbox: st.checkbox, disclosure_hidden_at_t0: atStart, disclosure_visible_in_viewport_at_end: st.disclosureInViewport, stReco: st.stReco });
      await p.screenshot({ path: ROOT + `qa/${variant.includes('offline') ? 'offline' : 'cdn'}_${vw}_${type}_${cases.length}.png` });
    }
    out.variants.push({ variant, viewport: `${vw}x${vh}`, errors: errs, cases, ok: !errs.length && cases.every(c => c.ok) });
    await p.close();
  }
}
await b.close(); out.all_pass = out.variants.every(v => v.ok);
fs.mkdirSync(ROOT + 'results', { recursive: true }); fs.writeFileSync(ROOT + 'results/UI_RUNTIME_CHECK.json', JSON.stringify(out, null, 1));
console.log('UI runtime check all_pass:', out.all_pass); for (const v of out.variants) console.log(v.variant, v.viewport, v.ok, v.errors, v.cases.map(c => `${c.type}:${c.ok}`).join(' '));
