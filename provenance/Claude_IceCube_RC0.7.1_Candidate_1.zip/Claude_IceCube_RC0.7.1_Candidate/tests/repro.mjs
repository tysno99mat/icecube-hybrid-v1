// Reproducibility helpers (R09). Raw hash = bitwise JSON of IEEE doubles (same-platform contract).
// Canonical hash = fixed field order + numbers rounded to 12 significant digits (artifact identity across platforms; raw data kept).
// compareWithTolerance = the authoritative cross-platform check: floats within max(absTol, relTol·|x|), everything else exact.
import crypto from 'crypto';
export const TOL = { relTol: 1e-9, absTol: 1e-12 };
export const strip = r => ({ ledger: r.ledger, hits: r.hits.map(h => [h.dom, h.t, h.tPhys, h.q, h.noise, h.clean]),
  reco: { fitStatus: r.reco.fitStatus, directionStatus: r.reco.directionStatus, fitDirection: r.reco.fitDirection, fitSpeed: r.reco.fitSpeed, vertexEstimate: r.reco.vertexEstimate } });
export const rawHash = o => crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex');
const canon = x => { if (typeof x === 'number') return Number.isInteger(x) ? x : (Number.isFinite(x) ? Number(x.toPrecision(12)) : String(x)); if (Array.isArray(x)) return x.map(canon); if (x && typeof x === 'object') { const o = {}; for (const k of Object.keys(x).sort()) o[k] = canon(x[k]); return o; } return x; };
export const canonicalHash = o => crypto.createHash('sha256').update(JSON.stringify(canon(o))).digest('hex');
export function compareWithTolerance(a, b, tol = TOL) {
  let maxRel = 0; const mismatches = [];
  const walk = (x, y, path) => {
    if (typeof x === 'number' && typeof y === 'number') { if (Number.isInteger(x) && Number.isInteger(y) && Math.abs(x) < 1e6) { if (x !== y) mismatches.push({ path, x, y }); return; }
      const d = Math.abs(x - y), sc = Math.max(Math.abs(x), Math.abs(y)); if (sc > 0) maxRel = Math.max(maxRel, d / sc); if (d > Math.max(tol.absTol, tol.relTol * sc)) mismatches.push({ path, x, y }); return; }
    if (Array.isArray(x) && Array.isArray(y)) { if (x.length !== y.length) { mismatches.push({ path, len: [x.length, y.length] }); return; } x.forEach((v, i) => walk(v, y[i], path + '[' + i + ']')); return; }
    if (x && y && typeof x === 'object' && typeof y === 'object') { for (const k of new Set([...Object.keys(x), ...Object.keys(y)])) walk(x[k], y[k], path + '.' + k); return; }
    if (x !== y) mismatches.push({ path, x, y });
  };
  walk(a, b, '$'); return { ok: mismatches.length === 0, maxRel, mismatches };
}
