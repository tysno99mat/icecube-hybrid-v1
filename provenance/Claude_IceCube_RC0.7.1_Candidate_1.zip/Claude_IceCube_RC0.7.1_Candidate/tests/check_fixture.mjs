// Usage: node tests/check_fixture.mjs '{"seed":40003618,"type":"starting","vertex":[x,y,z],"direction":[dx,dy,dz],"energy":100}'
// Prints what RC0.7.1 outputs for an exact EventInput, including the simulation-QA angular error and the labels shown to users.
const K = await import(new URL('../src/core.mjs', import.meta.url));
const inp = JSON.parse(process.argv[2]);
const r = K.simulateEvent(inp);
if (r.status !== 'OK') { console.log(JSON.stringify(r, null, 1)); process.exit(0); }
console.log(JSON.stringify({ version: K.VERSION, input: r.input, fitStatus: r.reco.fitStatus, directionStatus: r.reco.directionStatus, disclaimers: r.reco.disclaimers, qa: r.qa }, null, 1));
