// Run the reproducibility inputs in this runtime and print raw/canonical hashes and the stripped results.
import fs from 'fs';
const K = await import(new URL('../src/core.mjs', import.meta.url));
const { strip, rawHash, canonicalHash } = await import(new URL('./repro.mjs', import.meta.url));
const inputs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const results = inputs.map(i => strip(K.simulateEvent(i)));
process.stdout.write(JSON.stringify({ runtime: `node ${process.version} / V8 ${process.versions.v8}`, raw_hash: rawHash(results), canonical_hash: canonicalHash(results), results }));
