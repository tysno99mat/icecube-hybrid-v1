// Compare a fresh run (results/) with the frozen snapshot (results_frozen/) under the RC0.7 reproducibility contract:
// numbers within tolerance (relTol 1e-9, absTol 1e-12); integers/strings/booleans exact.
// Excluded: strict-IEEE roundoff diagnostics (platform-dependent counts of results within tolerance; material failures ARE compared),
// run metadata, runtime-specific hashes and the cross-runtime listing (they are platform evidence, not observables).
import fs from 'fs'; import { compareWithTolerance } from './repro.mjs';
const EXCL = /^(meta|runtime_s|date_utc|raw_run1|raw_run2|raw_fresh_process|raw_hash|canonical_hash|canonical_hash_local|cross_runtime|runtimes|sha_.*|skipped|runtime_check|runtime|strict_IEEE_failures|worst_strict_ratio|strictFail|worstStrict|R09b_cross_runtime_numeric_contract|source|stReco)$/;
const clean = x => { if (Array.isArray(x)) return x.map(clean); if (x && typeof x === 'object') { const o = {}; for (const k of Object.keys(x)) if (!EXCL.test(k)) o[k] = clean(x[k]); return o; } return x; };
let ok = true;
for (const f of fs.readdirSync('results_frozen')) {
  if (!f.endsWith('.json') || f.startsWith('_')) continue;
  if (!fs.existsSync('results/' + f)) { console.log('NOT RE-RUN', f, '(produced by an optional step, e.g. tests/ui_runtime_check.mjs needs Playwright)'); continue; }
  const c = compareWithTolerance(clean(JSON.parse(fs.readFileSync('results_frozen/' + f))), clean(JSON.parse(fs.readFileSync('results/' + f))));
  console.log(c.ok ? 'SAME (within tolerance)' : 'DIFF', f, c.ok ? '' : JSON.stringify(c.mismatches.slice(0, 3))); ok &&= c.ok;
}
process.exit(ok ? 0 : 1);
