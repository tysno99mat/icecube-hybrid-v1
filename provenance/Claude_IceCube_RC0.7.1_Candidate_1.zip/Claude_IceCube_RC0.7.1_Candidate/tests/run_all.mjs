// RC0.7 regression suite — one command: `node tests/run_all.mjs` (offline after vendored three is unpacked).
// Writes results/*.json; exit 1 if any gate fails. Gates follow the RC0.7 brief (R01–R10) plus the retained RC0.6 gates.
import * as K from '../src/core.mjs';
import * as K6 from './reference/rc06/core_rc06.mjs';
import * as K7 from './reference/rc07/core_rc07.mjs';
import { gptModel } from './reference/rc05/gpt_core.mjs';
import * as OLD from './reference/rc05/claude_core_rc05.mjs';
import { fixedEvents, segmentOf, GPT_Y_OFFSET } from './reference/rc05/events.mjs';
import * as THREE from '../node_modules/three/build/three.module.js';
import fs from 'fs'; import crypto from 'crypto'; import { execFileSync } from 'child_process'; import os from 'os';
import { canonicalHash, rawHash, compareWithTolerance, strip } from './repro.mjs';

const OUT = new URL('../results/', import.meta.url).pathname; fs.mkdirSync(OUT, { recursive: true });
const ROOT = new URL('..', import.meta.url).pathname;
const qnt = (a, p) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const i = (s.length - 1) * p; const lo = Math.floor(i), hi = Math.ceil(i); return s[lo] + (s[hi] - s[lo]) * (i - lo); };
const med = a => qnt(a, 0.5); const mean = a => a.reduce((x, y) => x + y, 0) / a.length; const vari = a => { const m = mean(a); return a.reduce((x, y) => x + (y - m) ** 2, 0) / (a.length - 1); };
const sha = o => crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex');
const GATES = {}; const R = { meta: { core: K.VERSION, node: process.version, v8: process.versions.v8, platform: `${os.platform()} ${os.arch()}`, date_utc: new Date().toISOString() } };
const gate = (name, pass, detail) => { GATES[name] = { pass: !!pass, ...detail }; console.log(`${pass ? 'PASS' : 'FAIL'}  ${name}  ${JSON.stringify(detail).slice(0, 240)}`); };
const save = (f, o) => fs.writeFileSync(OUT + f, JSON.stringify(o, null, 1));
const T0 = Date.now(); const MAX = Number.MAX_VALUE;
const BASE = { seed: 7, type: 'through', vertex: [0, -2000, 0], direction: [0.6, -0.8, 0], energy: 100 };

/* ============ R01 scale-safe normalisation + strict input checks ============ */
{
  const legal = [['MAX_MAX_0', [MAX, MAX, 0], [Math.SQRT1_2, Math.SQRT1_2, 0]], ['MAX_MAX_MAX', [MAX, MAX, MAX], [1 / Math.sqrt(3), 1 / Math.sqrt(3), 1 / Math.sqrt(3)]], ['MAX_1_0', [MAX, 1, 0], [1, 1 / MAX, 0]],
    ['1e-308_1e-308_0', [1e-308, 1e-308, 0], [Math.SQRT1_2, Math.SQRT1_2, 0]], ['min_subnormal', [5e-324, 0, 0], [1, 0, 0]], ['neg_MAX', [-MAX, 0, MAX], [-Math.SQRT1_2, 0, Math.SQRT1_2]], ['ordinary', [3, -4, 0], [0.6, -0.8, 0]]]
    .map(([name, d, expect]) => { const v = K.validateEventInput({ ...BASE, direction: d }); const u = v.ok ? v.input.direction : null; const err = u ? Math.max(...u.map((x, i) => Math.abs(x - expect[i]))) : null; const n = u ? Math.hypot(...u) : null; return { name, ok: v.ok, unit: u, max_abs_err_vs_expected: err, unit_norm: n }; });
  const legalOK = legal.every(l => l.ok && l.max_abs_err_vs_expected <= 4e-16 && Math.abs(l.unit_norm - 1) <= 4e-16);
  // rescaling: exact (powers of two) → bitwise-identical events; inexact → unit vectors within 2 ulp and identical observable counts
  const rng = K.mulberry32(1701); const resc = [];
  for (let i = 0; i < 12; i++) {
    const d = [rng() - 0.5, rng() - 0.5, rng() - 0.5]; const base = K.simulateEvent({ ...BASE, seed: 100 + i, direction: d });
    for (const k of [2 ** -1000, 2 ** -60, 2 ** 40, 2 ** 1000]) { const r = K.simulateEvent({ ...BASE, seed: 100 + i, direction: d.map(x => x * k) }); resc.push({ i, scale: `2^${Math.log2(k)}`, exact: true, same_unit: JSON.stringify(r.input.direction) === JSON.stringify(base.input.direction), same_hits: sha(r.hits) === sha(base.hits) }); }
    for (const k of [1e-300, 3.7, 1e300]) { const r = K.simulateEvent({ ...BASE, seed: 100 + i, direction: d.map(x => x * k) }); const du = Math.max(...r.input.direction.map((x, j) => Math.abs(x - base.input.direction[j]))); resc.push({ i, scale: String(k), exact: false, unit_max_abs_diff: du, hits_base: base.hits.length, hits_scaled: r.hits.length, same_hits: sha(r.hits) === sha(base.hits) }); }
  }
  const rescOK = resc.filter(r => r.exact).every(r => r.same_unit && r.same_hits) && resc.filter(r => !r.exact).every(r => r.unit_max_abs_diff <= 4.5e-16);
  // malformed inputs — all must be INVALID_INPUT before any physics
  const sparse = [0, -2000]; sparse.length = 3; const holeDir = [1, , 0]; // eslint-disable-line no-sparse-arrays
  let getterReads = 0; const getterDir = []; Object.defineProperty(getterDir, 0, { get() { getterReads++; return getterReads === 1 ? 1 : NaN; }, enumerable: true }); getterDir[1] = 0; getterDir[2] = 0;
  const throwingDir = new Proxy([1, 0, 0], { get(t, p) { if (p === '0') throw new Error('boom'); return t[p]; } });
  const throwingInput = { ...BASE }; Object.defineProperty(throwingInput, 'energy', { get() { throw new Error('boom'); } });
  const malformed = [
    ['zero_vector', { direction: [0, 0, 0] }], ['negative_zero', { direction: [-0, 0, -0] }], ['NaN_direction', { direction: [NaN, 0, 1] }], ['Infinity_direction', { direction: [Infinity, 0, 0] }], ['-Infinity_direction', { direction: [0, -Infinity, 0] }],
    ['hole_direction', { direction: holeDir }], ['sparse_vertex_length3', { vertex: sparse }], ['direction_len2', { direction: [1, 0] }], ['direction_len4', { direction: [1, 0, 0, 0] }],
    ['string_component', { direction: ['1', 0, 0] }], ['Number_object', { direction: [new Number(1), 0, 0] }], ['boolean_component', { direction: [true, 0, 0] }], ['bigint_component', { direction: [1n, 0, 0] }],
    ['typed_array', { direction: new Float64Array([1, 0, 0]) }], ['array_like_object', { direction: { 0: 1, 1: 0, 2: 0, length: 3 } }], ['throwing_proxy', { direction: throwingDir }],
    ['zero_energy', { energy: 0 }], ['negative_energy', { energy: -1 }], ['NaN_energy', { energy: NaN }], ['Infinity_energy', { energy: Infinity }], ['huge_energy_1e12', { energy: 1e12 }], ['tiny_energy_1e-12', { energy: 1e-12 }], ['Number_energy', { energy: new Number(100) }],
    ['unsupported_type', { type: 'double_bang' }], ['String_object_type', { type: new String('through') }], ['NaN_vertex', { vertex: [NaN, -2000, 0] }], ['bedrock_vertex', { vertex: [0, -2900, 0] }], ['above_surface', { vertex: [0, 10, 0] }],
    ['outside_detector_x', { vertex: [1200, -2000, 0] }], ['seed_float', { seed: 1.5 }], ['seed_negative', { seed: -3 }], ['seed_string', { seed: '7' }], ['seed_too_big', { seed: 2 ** 32 }],
  ].map(([name, patch]) => { const r = K.simulateEvent({ ...BASE, ...patch }); return { name, status: r.status, first_error: r.errors?.[0] ?? null }; });
  for (const [name, inp] of [['null_input', null], ['array_input', [1, 2, 3]], ['throwing_getter_input', throwingInput]]) { const r = K.simulateEvent(inp); malformed.push({ name, status: r.status, first_error: r.errors?.[0] ?? null }); }
  const g = K.validateEventInput({ ...BASE, direction: getterDir }); malformed.push({ name: 'getter_read_once', status: g.ok ? 'OK(read once)' : 'INVALID_INPUT', reads: getterReads, used: g.ok ? g.input.direction : null });
  const malformedOK = malformed.filter(m => m.name !== 'getter_read_once').every(m => m.status === 'INVALID_INPUT') && getterReads === 1 && g.ok && g.input.direction[0] === 1;
  const p001_rc06 = K6.validateEventInput({ ...BASE, direction: [MAX, MAX, 0] });
  const sparse_rc06 = K6.validateEventInput({ ...BASE, type: 'cascade', vertex: sparse });
  let uiBad = 0; for (let s = 1; s <= 30000; s++) if (!K.validateEventInput(K.sampleEventInput(['through', 'starting', 'cascade'][s % 3], [1, 10, 100, 1000, 10000][s % 5], ['up', 'down', 'any'][s % 3], s)).ok) uiBad++;
  R.input = { contract: K.CONTRACT, legal, rescaling: resc, malformed, permanent: { P0_01_MAX_direction_rc06: p001_rc06.input?.direction ?? p001_rc06, P0_01_rc07: legal[0], sparse_vertex_rc06_accepted: sparse_rc06.ok }, ui_sampler_checked: 30000, ui_sampler_rejected: uiBad };
  save('INPUT_NUMERICAL_SAFETY_TESTS.json', R.input);
  gate('R01a_scale_safe_normalization', legalOK && rescOK, { legal: legal.map(l => `${l.name}:${l.ok}`), exact_rescales_bitwise: resc.filter(r => r.exact).every(r => r.same_hits), inexact_max_unit_diff: Math.max(...resc.filter(r => !r.exact).map(r => r.unit_max_abs_diff)) });
  gate('R01b_malformed_sparse_rejected', malformedOK && uiBad === 0, { fixtures: malformed.length, rejected: malformed.filter(m => m.status === 'INVALID_INPUT').length, getterReads, uiBad });
}

/* ============ R02–R04 LineFit semantics + R03 cascade non-identifiability ============ */
{
  const FORBIDDEN = ['USABLE', '方向可用', '方向通過可信度檢查', '可靠方向', '可信方向', '重建方向', '有徑跡可抓方向', '真實來向', '真實路徑', 'validated direction', 'reliable direction', 'direction confidence'];
  const corePublic = fs.readFileSync(ROOT + 'src/core.mjs', 'utf8').split('\n').filter(l => !l.trim().startsWith('//')).join('\n');
  const tpl = ['app/app_template.html', 'dist/icecube_rc071.html', 'dist/icecube_rc071_artifact_body.html', 'dist/offline/index.html'].filter(f => fs.existsSync(ROOT + f)).map(f => fs.readFileSync(ROOT + f, 'utf8')).join('\n');
  const hitsForbidden = FORBIDDEN.flatMap(w => [...(corePublic.includes(w) ? [`core:${w}`] : []), ...(tpl.includes(w) ? [`app:${w}`] : [])]);
  // cascades: direction never output; flipping the truth leaves the hits bit-identical
  const casc = []; let flipIdentical = 0, dirOut = 0;
  const cseeds = [40005452, ...Array.from({ length: 199 }, (_, i) => 61000000 + i)];
  for (const s of cseeds) { const inp = K.sampleEventInput('cascade', [10, 100, 1000][s % 3], 'any', s); const a = K.simulateEvent(inp); const b = K.simulateEvent({ ...inp, direction: inp.direction.map(x => -x) });
    const same = sha(a.hits) === sha(b.hits); if (same) flipIdentical++; if (a.reco.fitDirection || a.reco.fitSpeed || a.reco.directionStatus !== 'NOT_IDENTIFIABLE_IN_PEDAGOGICAL_CASCADE_MODEL') dirOut++;
    if (s === 40005452) casc.push({ seed: s, flip_hits_identical: same, directionStatus: a.reco.directionStatus, fitDirection: a.reco.fitDirection, vertexStatus: a.reco.vertexStatus, rc06_status: K6.simulateEvent(inp).reco.status }); }
  // track fixtures: RC0.6 labelled these USABLE although the LineFit direction is in the wrong hemisphere
  const p02 = [[7006668, 100], [7003149, 10], [40003618, 100]].map(([seed, E]) => { const inp = K.sampleEventInput('starting', E, 'any', seed); const r6 = K6.simulateEvent(inp); const r7 = K.simulateEvent(inp);
    return { seed, E, generator: "sampleEventInput('starting', E, 'any', seed)", rc06_status: r6.reco.status, rc06_err_deg: K6.qaAngularError(r6.reco.dir, inp.direction), rc07_fitStatus: r7.reco.fitStatus, rc07_directionStatus: r7.reco.directionStatus, rc07_disclaimers: r7.reco.disclaimers, qa: r7.qa }; });
  const trackOK = p02.slice(0, 2).every(p => p.rc06_status === 'USABLE' && p.rc06_err_deg > 90 && p.rc07_directionStatus === 'ILLUSTRATIVE_LINEFIT' && p.rc07_disclaimers.includes(K.DISCLAIMERS.noValidation));
  // every track reco carries the disclaimers; no tier name implies accuracy
  let missingDisc = 0; for (let s = 1; s <= 200; s++) { const r = K.simulateEvent(K.sampleEventInput(s % 2 ? 'through' : 'starting', 100, 'any', 62000000 + s)); if (!(r.reco.disclaimers.includes(K.DISCLAIMERS.linefit) && r.reco.disclaimers.includes(K.DISCLAIMERS.noValidation) && r.reco.disclaimers.includes(K.DISCLAIMERS.speed))) missingDisc++; if (!('qa' in r) || 'trueDirection' in r.reco) missingDisc++; }
  R.semantics = { fit_tiers: K.FIT_TIERS, forbidden_phrases_found: hitsForbidden, cascade: { seeds: cseeds.length, flip_identical: flipIdentical, direction_output: dirOut, permanent_fixture: casc[0] }, track_fixtures: p02,
    note_P0_02: 'The exact GPT re-audit input for seed 40003618 was not available to Claude; under sampleEventInput(\'starting\',100,\'any\',40003618) RC0.6 does not reproduce the 123.198° case. Two analogue fixtures (7006668, 7003149) found in a dedicated search range (7,000,000–7,008,000, excluded from the hold-out) reproduce the failure class: RC0.6 USABLE with the LineFit direction in the wrong hemisphere.' , track_missing_disclaimers_or_truth_leak: missingDisc };
  save('RECONSTRUCTION_SEMANTICS_TESTS.json', R.semantics);
  gate('R03_cascade_never_claims_direction', flipIdentical === cseeds.length && dirOut === 0, { seeds: cseeds.length, flipIdentical, dirOut });
  gate('R02_R04_linefit_never_claims_validation', hitsForbidden.length === 0 && trackOK && missingDisc === 0, { forbidden: hitsForbidden, p02: p02.map(p => `${p.seed}:rc06=${p.rc06_status}/${p.rc06_err_deg?.toFixed(1)}°→rc07=${p.rc07_directionStatus}`), missingDisc });
}

/* ============ R05 exact Poisson at all μ + high-μ partition ============ */
{
  const logPmf = (k, mu) => -mu + k * Math.log(mu) - K.loggam(k + 1);
  const exactCdfTable = (mu) => { const lo = Math.max(0, Math.floor(mu - 12 * Math.sqrt(mu) - 20)), hi = Math.ceil(mu + 12 * Math.sqrt(mu) + 30); const pm = []; for (let k = lo; k <= hi; k++) pm.push(Math.exp(logPmf(k, mu))); return { lo, pm }; };
  const chi2p = (x, df) => { const z = (Math.cbrt(x / df) - (1 - 2 / (9 * df))) / Math.sqrt(2 / (9 * df)); return 0.5 * erfc(z / Math.SQRT2); };
  function erfc(x) { const t = 1 / (1 + 0.5 * Math.abs(x)); const y = t * Math.exp(-x * x - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277))))))))); return x >= 0 ? y : 2 - y; }
  const gof = (samples, mu) => { const { lo, pm } = exactCdfTable(mu); const N = samples.length; const cnt = new Map(); for (const k of samples) cnt.set(k, (cnt.get(k) || 0) + 1);
    // merge bins so every expected count ≥ 5
    const bins = []; let e = 0, o = 0; const lowTail = (() => { let s = 0; for (let k = 0; k < lo; k++) s += Math.exp(logPmf(k, mu)); return s; })(); e = lowTail * N; for (let k = 0; k < lo; k++) o += cnt.get(k) || 0;
    for (let i = 0; i < pm.length; i++) { e += pm[i] * N; o += cnt.get(lo + i) || 0; if (e >= 5) { bins.push([o, e]); e = 0; o = 0; } }
    let rest = 0; for (const [k, c] of cnt) if (k > lo + pm.length - 1) rest += c; o += rest; e += Math.max(0, N - bins.reduce((a, b) => a + b[1], 0) - e); if (bins.length) { bins[bins.length - 1][0] += o; bins[bins.length - 1][1] += e; }
    const x2 = bins.reduce((a, [O, E]) => a + (O - E) ** 2 / E, 0); const df = bins.length - 1; return { chi2: x2, df, p: chi2p(x2, df) }; };
  const exactQuantile = (mu, p) => { let k = 0, c = 0; const { lo, pm } = exactCdfTable(mu); for (let kk = 0; kk < lo; kk++) c += Math.exp(logPmf(kk, mu)); k = lo; for (const v of pm) { c += v; if (c >= p) return k; k++; } return k; };
  const N = 200000; const rows = [];
  for (const mu of [0.1, 1, 10, 30, 31, 100, 1000, 10000]) {
    const Rr = K._internal.makeRandom(K.mulberry32(Math.round(mu * 1000) + 17)); const s = Array.from({ length: N }, () => Rr.poisson(mu));
    const m = mean(s), v = vari(s); const tailK = Math.ceil(mu + 3 * Math.sqrt(mu)); const tailObs = s.filter(x => x >= tailK).length / N; let tailExact = 0; { const { lo, pm } = exactCdfTable(mu); pm.forEach((p, i) => { if (lo + i >= tailK) tailExact += p; }); }
    const G = gof(s, mu);
    rows.push({ mu, mean: m, mean_z: (m - mu) / Math.sqrt(mu / N), var: v, var_ratio: v / mu, q01: qnt(s, 0.01), q01_exact: exactQuantile(mu, 0.01), q50: qnt(s, 0.5), q50_exact: exactQuantile(mu, 0.5), q99: qnt(s, 0.99), q99_exact: exactQuantile(mu, 0.99), tail_k: tailK, tail_obs: tailObs, tail_exact: tailExact, chi2: G.chi2, df: G.df, p_value: G.p });
  }
  // legacy RC0.6 rounded Gaussian at μ = 31 and 100 (contrast)
  const legacy = [31, 100].map(mu => { const Rr = K6._internal.makeRandom(K6.mulberry32(99 + mu)); const s = Array.from({ length: N }, () => Rr.poisson(mu)); const G = gof(s, mu); return { mu, rc06_chi2: G.chi2, df: G.df, p_value: G.p }; });
  // split/merge of the counting variable and of the first-photon time at high μ
  const part = [];
  for (const muTot of [100, 1000, 10000]) for (const parts of [10, 100]) {
    const Ra = K._internal.makeRandom(K.mulberry32(muTot + parts)), Rb = K._internal.makeRandom(K.mulberry32(muTot * 7 + parts));
    const M = 40000; const merged = [], split = [];
    for (let i = 0; i < M; i++) { merged.push(Ra.poisson(muTot)); let t = 0; for (let j = 0; j < parts; j++) t += Rb.poisson(muTot / parts); split.push(t); }
    const ks = ksD(merged, split); part.push({ muTot, parts, merged_mean: mean(merged), split_mean: mean(split), merged_var: vari(merged), split_var: vari(split), KS: ks, KS_crit_1e3: 1.95 * Math.sqrt(2 / M), gof_merged_p: gof(merged, muTot).p, gof_split_p: gof(split, muTot).p });
  }
  function ksD(a, b) { const A = [...a].sort((x, y) => x - y), B = [...b].sort((x, y) => x - y); let i = 0, j = 0, d = 0; while (i < A.length && j < B.length) { const x = Math.min(A[i], B[j]); while (i < A.length && A[i] <= x) i++; while (j < B.length && B[j] <= x) j++; d = Math.max(d, Math.abs(i / A.length - j / B.length)); } return d; }
  // DOM-level: one co-located source vs 100 pieces at μ = 1000 (photon count and first-photon time)
  const D = K.doms.find(d => d.str === 79 && d.om === 30); const idx = K.indices();
  const domPart = [1000, 30].map(muTot => { const run = parts => { const ns = [], ts = []; for (let s = 0; s < 20000; s++) { const Rr = K._internal.makeRandom(K.mulberry32(3000000 + s + parts)); const h = K.domResponse(Array.from({ length: parts }, () => ({ mu: muTot / parts, t: 10, path: 50 })), Rr, { scatter: true, jitter: false }); if (h) { ns.push(h.n); ts.push(h.tPhys); } } return { ns, ts }; };
    const a = run(1), b = run(100); return { muTot, n_KS: ksD(a.ns, b.ns), t_KS: ksD(a.ts, b.ts), n_mean: [mean(a.ns), mean(b.ns)], t_median: [med(a.ts), med(b.ts)], crit: 1.95 * Math.sqrt(2 / 20000) }; });
  R.poisson = { samples_per_mu: N, sampler: 'mu<10 multiplication (Knuth); mu>=10 PTRS (Hörmann 1993)', rows, legacy_rc06_gaussian: legacy, partition_counts: part, partition_dom: domPart };
  save('POISSON_HIGH_MU_TESTS.json', R.poisson);
  const okRows = rows.every(r => Math.abs(r.mean_z) < 4.5 && Math.abs(r.var_ratio - 1) < 0.02 && r.p_value > 1e-4 && Math.abs(r.q01 - r.q01_exact) <= 1 && Math.abs(r.q99 - r.q99_exact) <= 1);
  const okPart = part.every(p => p.KS < p.KS_crit_1e3 && p.gof_merged_p > 1e-4 && p.gof_split_p > 1e-4) && domPart.every(d => d.n_KS < d.crit && d.t_KS < d.crit);
  gate('R05_poisson_all_mu_and_partition', okRows && okPart, { p_values: rows.map(r => `${r.mu}:${r.p_value.toExponential(1)}`), rc06_legacy_p: legacy.map(l => `${l.mu}:${l.p_value.toExponential(1)}`), maxKS: Math.max(...part.map(p => p.KS)).toFixed(4) });
}

/* ============ R06 Weibull disclosure (characterisation; gate = disclosure present) ============ */
{
  const gam = x => Math.exp(K.loggam(x)); const k = K.WEIBULL_K; const lam = 1 / gam(1 + 1 / k);  // mean 1
  const varW = lam * lam * (gam(1 + 2 / k) - gam(1 + 1 / k) ** 2);
  const tail = c => ({ c, weibull: Math.exp(-((c / lam) ** k)), exponential: Math.exp(-c) });
  const Rr = K._internal.makeRandom(K.mulberry32(66)); const M = 400000; const w = Array.from({ length: M }, () => lam * Math.pow(-Math.log(1 - Rr.rng()), 1 / k));
  const tpl = fs.readFileSync(ROOT + 'app/app_template.html', 'utf8'); const DISC = 'WEIBULL FIRST-PHOTON TEACHING MODEL — UNCALIBRATED';
  R.weibull = { shape_k: k, mean: 1, variance_weibull: varW, variance_exponential: 1, variance_ratio: varW, empirical_mean: mean(w), empirical_var: vari(w), tails: [2, 3, 5].map(tail), disclosure_in_app: tpl.includes(DISC), disclosure_in_core: fs.readFileSync(ROOT + 'src/core.mjs', 'utf8').includes(DISC),
    statement: 'Same mean law as RC0.5 (0.8·d/n^0.7) but about half the variance and a much lighter tail. Scattering physics was NOT preserved by RC0.6; the mean-law check (G9) does not imply an unchanged scattering model.' };
  save('WEIBULL_DISCLOSURE.json', R.weibull);
  gate('R06_weibull_disclosed', R.weibull.disclosure_in_app && R.weibull.disclosure_in_core && Math.abs(mean(w) - 1) < 0.01, { variance_ratio: +varW.toFixed(4), tail3: R.weibull.tails[1] });
}

/* ============ R07 ice boundary numerics vs exact rational reference ============ */
{
  const F = { make: (n, d = 1n) => { if (d < 0n) { n = -n; d = -d; } const g = gcd(n < 0n ? -n : n, d); return { n: n / g, d: d / g }; } };
  function gcd(a, b) { while (b) { [a, b] = [b, a % b]; } return a || 1n; }
  const fromD = x => { if (x === 0) return F.make(0n); const buf = new DataView(new ArrayBuffer(8)); buf.setFloat64(0, x); const bits = buf.getBigUint64(0); const sign = bits >> 63n ? -1n : 1n; const e = Number((bits >> 52n) & 0x7ffn); let m = bits & 0xfffffffffffffn; let exp; if (e === 0) exp = -1074; else { m |= 1n << 52n; exp = e - 1075; } return exp >= 0 ? F.make(sign * m * (1n << BigInt(exp))) : F.make(sign * m, 1n << BigInt(-exp)); };
  const add = (a, b) => F.make(a.n * b.d + b.n * a.d, a.d * b.d), sub = (a, b) => F.make(a.n * b.d - b.n * a.d, a.d * b.d), mul = (a, b) => F.make(a.n * b.n, a.d * b.d), div = (a, b) => F.make(a.n * b.d, a.d * b.n);
  const toD = a => { if (a.n === 0n) return 0; const neg = a.n < 0n; let n = neg ? -a.n : a.n; const sh = BigInt(a.d.toString(2).length - n.toString(2).length + 80); const qq = sh >= 0n ? (n << sh) / a.d : n / (a.d << -sh); return (neg ? -1 : 1) * Number(qq) * Math.pow(2, -Number(sh)); };
  const LAY = K._internal.LAYERS.map(([a, b, v]) => [F.make(BigInt(a)), F.make(BigInt(b)), fromD(v)]);
  const exactTau = (yA, yB, L) => { const dA = fromD(-yA), dB = fromD(-yB); const Lf = fromD(L);
    const cmp = (a, b) => { const x = a.n * b.d - b.n * a.d; return x < 0n ? -1 : x > 0n ? 1 : 0; };
    if (cmp(dA, dB) === 0) { const dd = toD(dA); return L * K.invLambda(dd); }
    const lo = cmp(dA, dB) < 0 ? dA : dB, hi = cmp(dA, dB) < 0 ? dB : dA; const span = sub(hi, lo); let acc = F.make(0n);
    for (const [a, b, v] of LAY) { const s0 = cmp(lo, a) > 0 ? lo : a, s1 = cmp(hi, b) < 0 ? hi : b; if (cmp(s1, s0) > 0) acc = add(acc, mul(sub(s1, s0), v)); }
    return toD(mul(Lf, div(acc, span))); };
  const cases = []; const rng = K.mulberry32(777);
  for (let i = 0; i < 1500; i++) { const yA = -(1200 + rng() * 1500), yB = Math.min(-1, Math.max(-2810, yA + (rng() - 0.5) * 1600)); cases.push({ kind: 'ordinary', yA, yB, L: Math.hypot(yB - yA, rng() * 600) }); }
  for (const b of [1400, 2000, 2100, 2450]) for (const dz of [1e-3, 1e-6, 1e-9, 1e-11, 4e-13]) for (const f of [0.1, 0.5, 0.9]) cases.push({ kind: 'near_horizontal_crossing', yA: -(b - dz * f), yB: -(b + dz * (1 - f)), L: 300 });
  for (const b of [1400, 2000, 2100, 2450]) for (const d of [-50, 50]) { cases.push({ kind: 'boundary_touch', yA: -b, yB: -(b + d), L: 80 }); cases.push({ kind: 'horizontal_on_boundary', yA: -b, yB: -b, L: 120 }); }
  cases.push({ kind: 'sub_nm_crossing_fixture', yA: -(2000 - 4e-10), yB: -(2000 + 1e-10), L: 300 });
  let maxRel = 0; const worst = []; const rows = cases.map(c => { const ex = exactTau(c.yA, c.yB, c.L), nw = K.opticalDepth(c.yA, c.yB, c.L), l6 = K.opticalDepthRC06Legacy(c.yA, c.yB, c.L); const rel = Math.abs(nw - ex) / Math.max(ex, 1e-300); maxRel = Math.max(maxRel, rel); return { ...c, exact: ex, rc07: nw, rc06: l6, rel_err_rc07: rel, rc06_throughput_factor: Math.exp(Math.abs(l6 - ex)) }; });
  const fx = rows.find(r => r.kind === 'sub_nm_crossing_fixture');
  const byKind = {}; for (const r of rows) { const b = byKind[r.kind] ||= { n: 0, max_rel_err_rc07: 0, max_rc06_throughput_factor: 1 }; b.n++; b.max_rel_err_rc07 = Math.max(b.max_rel_err_rc07, r.rel_err_rc07); b.max_rc06_throughput_factor = Math.max(b.max_rc06_throughput_factor, r.rc06_throughput_factor); }
  const dustFixture = { exact: exactTau(-1900, -2400, 500), rc07: K.opticalDepth(-1900, -2400, 500), three_point_legacy: K.opticalDepthThreePointLegacy(-1900, -2400, 500) };
  R.ice = { reference: 'exact rational arithmetic (BigInt) on the same double-valued layer coefficients', numeric_domain: K.ICE_NUMERIC_DOMAIN, by_kind: byKind, max_rel_err_rc07: maxRel, sub_nm_fixture: fx, dust_fixture_rc06: dustFixture };
  save('ICE_BOUNDARY_TESTS.json', { ...R.ice, cases: rows });
  gate('R07_ice_boundary_numeric_domain', maxRel <= 1e-12 && fx.rel_err_rc07 <= 1e-12, { maxRel, sub_nm_rc06_factor: fx.rc06_throughput_factor, by_kind: Object.fromEntries(Object.entries(byKind).map(([k, v]) => [k, v.max_rel_err_rc07])) });
}

/* ============ R08 material energy conservation (strict IEEE reported separately) ============ */
{
  let checked = 0, strictFail = 0, materialFail = 0, worstStrict = 0, maxRes = 0; const matEx = [];
  const run = (inp, tag) => { const v = K.validateEventInput(inp).input; const ev = K.buildEvent(v, K._internal.makeRandom(K.mulberry32((v.seed ^ 0x5bd1e995) >>> 0))); const c = K.checkConservation(ev.ledger); checked++;
    if (!c.strictIEEE) { strictFail++; worstStrict = Math.max(worstStrict, ev.ledger.totalDepositedEnergy / ev.ledger.initialEnergy); } if (!c.material) { materialFail++; if (matEx.length < 5) matEx.push({ tag, seed: v.seed, L: ev.ledger }); } maxRes = Math.max(maxRes, Math.abs(ev.ledger.residual) / ev.ledger.initialEnergy); };
  for (let s = 0; s < 100000; s++) run(K.sampleEventInput('through', 100, 'any', s), 'through100');
  for (const t of ['through', 'starting', 'cascade']) for (const E of [0.1, 1, 10, 100, 1000, 10000, 100000]) for (let s = 0; s < 1000; s++) run(K.sampleEventInput(t, E, ['up', 'down', 'any'][s % 3], 200000 + s), `${t}${E}`);
  const fxInp = K.sampleEventInput('starting', 1, 'any', 16051); const fxv = K.validateEventInput(fxInp).input; const fxEv = K.buildEvent(fxv, K._internal.makeRandom(K.mulberry32((fxv.seed ^ 0x5bd1e995) >>> 0)));
  const s1492 = K.simulateEvent(K.sampleEventInput('through', 100, 'any', 1492));
  R.energy = { tolerance: K.ENERGY_TOLERANCE, checked, strict_IEEE_failures: strictFail, worst_strict_ratio: worstStrict, material_failures: materialFail, material_examples: matEx, max_relative_residual: maxRes,
    permanent_strict_fixture: { input: fxInp, ledger: fxEv.ledger, ratio: fxEv.ledger.totalDepositedEnergy / fxEv.ledger.initialEnergy, check: K.checkConservation(fxEv.ledger) }, seed1492: { ledger: s1492.ledger, check: K.checkConservation(s1492.ledger) } };
  save('ENERGY_LEDGER_TESTS.json', R.energy);
  gate('R08_material_energy_conservation', materialFail === 0 && checked >= 100000 && K.checkConservation(fxEv.ledger).material && !K.checkConservation(fxEv.ledger).strictIEEE, { checked, strictFail, worstStrict, materialFail, maxRes });
}

/* ============ Retained RC0.6 gates: geometry, source partition (μ=1.5), causality ============ */
{
  const idx = K.indices(1.32, 1.32);
  const geom = K.doms.map(D => ({ si: D.str - 1, k: D.om - 1, depth: D.depth, p: [D.x, D.y + GPT_Y_OFFSET, D.z], core: D.str > 78, id: D.idx }));
  let n = 0, maxDt = 0, maxOld = 0;
  for (const e of fixedEvents()) { const seg = segmentOf(e); if (!seg) continue;
    const g = gptModel({ n: 1.32, L: seg.length, origin: [seg.start[0], seg.start[1] + GPT_Y_OFFSET, seg.start[2]], d: e.direction, geometry: geom });
    OLD.setIndices(1.32, 1.32); Object.assign(OLD.CFG, { poisson: true, scatter: false, jitter: false, noise: false, stochLosses: false, record: true });
    const o = OLD.makeEvent(e.type, e.energy, 'any', e.seed, { vertex: new THREE.Vector3(...e.vertex), dir: new THREE.Vector3(...e.direction), len: seg.length, back: seg.back });
    for (const D of K.doms) { const r = K.trackDirect(D, seg.start, e.direction, 0, seg.length, idx); const ot = o.records[D.idx].tracks[0];
      for (const k of ['along', 'd', 'se', 'path', 'scale', 'ey']) if (r[k] !== ot[k]) maxOld = Math.max(maxOld, Math.abs(r[k] - ot[k]) || 1);
      if (r.dRaw > 300 || r.dRaw < 3) continue; const s = g.sensors[D.idx]; if (r.scale === 1 && K.inIce(r.ey) && Number.isFinite(s.arrival)) { n++; maxDt = Math.max(maxDt, Math.abs(r.t - s.arrival * 1000)); } } }
  R.geometry = { both_direct_nonclamp: n, max_abs_dt_vs_GPT_ns: maxDt, max_abs_diff_vs_RC05_claude: maxOld };
  gate('G1_geometry_unchanged', n === 21646 && maxDt < 1e-6 && maxOld === 0, R.geometry);
  // μ = 1.5 single-DOM partition (RC0.6 fixture) under the new sampler
  const D = K.doms.find(d => d.str === 79 && d.om === 30); const ph = []; for (const parts of [1, 100]) { let h = 0; for (let s = 0; s < 20000; s++) { const Rr = K._internal.makeRandom(K.mulberry32(900000 + s)); if (K.domResponse(Array.from({ length: parts }, () => ({ mu: 1.5 / parts, t: 10, path: 3 })), Rr, { scatter: true, jitter: false })) h++; } ph.push(h / 20000); }
  const sig = Math.sqrt(0.7769 * 0.2231 / 20000) * Math.SQRT2;
  gate('G3_partition_mu1.5', Math.abs(ph[0] - ph[1]) < 4 * sig && Math.abs(ph[0] - (1 - Math.exp(-1.5))) < 4 * sig, { P_hit: ph });
  let phys = 0, early = 0; for (let s = 1; s <= 120; s++) { const r = K.simulateEvent(K.sampleEventInput(['through', 'starting', 'cascade'][s % 3], 500, 'any', 60000 + s)); for (const h of r.hits) { if (h.noise) continue; phys++; if (h.tPhys - h.tDirect < -1e-9) early++; } }
  gate('G8_causality_physical_time', early === 0, { physical_hits: phys, earlier_than_direct: early });
}

/* ============ R09 reproducibility: same-platform bitwise, cross-runtime numeric ============ */
{
  const inputs = Array.from({ length: 30 }, (_, i) => K.sampleEventInput(['through', 'starting', 'cascade'][i % 3], [3, 30, 300, 3000][i % 4], ['up', 'down', 'any'][i % 3], 777 + i));
  fs.writeFileSync(OUT + '_repro_inputs.json', JSON.stringify(inputs));
  const local = inputs.map(i => strip(K.simulateEvent(i)));
  const raw1 = rawHash(local), raw2 = rawHash(inputs.map(i => strip(K.simulateEvent(i))));
  const script = ROOT + 'tests/repro_child.mjs';
  const child = JSON.parse(execFileSync(process.execPath, [script, OUT + '_repro_inputs.json']).toString());
  const runtimes = [];
  const bins = [...new Set([...['20', '21', '22'].map(v => `/opt/node${v}/bin/node`), ...(process.env.ICECUBE_ALT_NODES || '').split(':')].filter(b => b && fs.existsSync(b)))];
  for (const bin of bins) { try { const out = JSON.parse(execFileSync(bin, [script, OUT + '_repro_inputs.json'], { maxBuffer: 1 << 28 }).toString()); const cmp = compareWithTolerance(local, out.results); runtimes.push({ runtime: out.runtime, raw_hash: out.raw_hash, canonical_hash: out.canonical_hash, numeric_within_tolerance: cmp.ok, max_rel_diff: cmp.maxRel, mismatches: cmp.mismatches.slice(0, 3) }); } catch (e) { runtimes.push({ runtime: bin, error: String(e).slice(0, 200) }); } }
  R.reproducibility = { same_platform: { raw_run1: raw1, raw_run2: raw2, raw_fresh_process: child.raw_hash }, canonical_hash_local: canonicalHash(local), cross_runtime: runtimes, tolerance: { relTol: 1e-9, absTol: 1e-12 } };
  save('REPRODUCIBILITY_TESTS.json', R.reproducibility);
  gate('R09a_same_platform_determinism', raw1 === raw2 && raw2 === child.raw_hash, R.reproducibility.same_platform);
  const distinct = new Set(runtimes.filter(r => !r.error).map(r => r.runtime)).size;
  if (distinct >= 2) gate('R09b_cross_runtime_numeric_contract', runtimes.every(r => r.numeric_within_tolerance), { runtimes: runtimes.map(r => `${r.runtime}: raw=${r.raw_hash?.slice(0, 10)} canon=${r.canonical_hash?.slice(0, 10)} ok=${r.numeric_within_tolerance}`) });
  else { GATES.R09b_cross_runtime_numeric_contract = { pass: null, skipped: true, note: 'fewer than two Node runtimes available on this machine; set ICECUBE_ALT_NODES=/path/node20:/path/node21 to run. Frozen evidence in results_frozen/REPRODUCIBILITY_TESTS.json.' }; console.log('SKIP  R09b_cross_runtime_numeric_contract (no alternative runtimes found)'); }
}

/* ============ R10 hold-out characterisation (no tuning) ============ */
{
  const classes = { up: [120, 178], down: [2, 60], horizontal: [85, 95], near_vertical_down: [0, 5], near_vertical_up: [175, 180] };
  const mkDir = (rng, z0, z1) => { const cz = Math.cos(z0 * Math.PI / 180) - rng() * (Math.cos(z0 * Math.PI / 180) - Math.cos(z1 * Math.PI / 180)); const sz = Math.sqrt(Math.max(0, 1 - cz * cz)), ph = rng() * 2 * Math.PI; return [-sz * Math.cos(ph), -cz, -sz * Math.sin(ph)]; };
  const rows = []; const summary = []; let base = 900000000;
  for (const type of ['through', 'starting', 'cascade']) for (const E of [10, 100, 1000]) for (const [cls, [z0, z1]] of Object.entries(classes)) {
    const errs = []; let disp = 0, flips = 0, notId = 0, fitOut = 0, n = 0;
    for (let i = 0; i < 40; i++) { const seed = base++; const rng = K.mulberry32(seed ^ 0xabcdef); const r0 = 420 * Math.sqrt(rng()), a = rng() * 2 * Math.PI;
      const inp = { seed, type, vertex: [r0 * Math.cos(a), -(1600 + rng() * 700), r0 * Math.sin(a)], direction: mkDir(rng, z0, z1), energy: E };
      const r = K.simulateEvent(inp); n++; if (r.reco.fitStatus === 'FIT_RENDERABLE') disp++; if (r.reco.directionStatus === 'NOT_IDENTIFIABLE_IN_PEDAGOGICAL_CASCADE_MODEL') notId++; if (r.reco.fitDirection) fitOut++;
      if (r.qa.angularError_deg !== null) { errs.push(r.qa.angularError_deg); if (r.qa.hemisphereFlip) flips++; } }
    summary.push({ type, E, direction_class: cls, n, fit_displayable_rate: disp / n, direction_outputs: fitOut, not_identifiable: notId, median_err: med(errs), p68: qnt(errs, 0.68), p90: qnt(errs, 0.9), p95: qnt(errs, 0.95), hemisphere_flip_rate: errs.length ? flips / errs.length : null });
  }
  // synthetic noise-only hit sets
  const noise = { n: 0, statuses: {} }; const nr = K.mulberry32(990000001);
  for (let i = 0; i < 600; i++) { const N = 4 + Math.floor(nr() * 37); const hits = Array.from({ length: N }, () => ({ ...K.doms[Math.floor(nr() * 5160)], t: nr() * 5000, q: 0.4 + nr() })); const f = K.lineFit(hits); noise.n++; noise.statuses[f.fitStatus] = (noise.statuses[f.fitStatus] || 0) + 1; }
  R.holdout = { seeds: '900,000,000 – ' + (base - 1) + ' (new; disjoint from RC0.6 tuning/re-audit seeds and from the 7,000,000–7,008,000 fixture search)', purpose: 'characterisation only — no threshold was chosen from this population', summary, noise_only_linefit_status: noise };
  save('HOLDOUT_CHARACTERIZATION.json', R.holdout);
  const cascOK = summary.filter(s => s.type === 'cascade').every(s => s.direction_outputs === 0 && s.not_identifiable === s.n);
  gate('R10_holdout_cascade_outputs_none', cascOK, { cascade_rows: summary.filter(s => s.type === 'cascade').length });
}


/* ============ G15 revoked-Proxy safety (B-INPUT-01) ============ */
{
  const rows = []; let uncaught = 0;
  const mkRevoked = target => { const { proxy, revoke } = Proxy.revocable(target, {}); revoke(); return proxy; };
  const fixtures = [['revoked_event_proxy', () => mkRevoked({ ...BASE })], ['revoked_vertex_proxy', () => ({ ...BASE, vertex: mkRevoked([0, -2000, 0]) })], ['revoked_direction_proxy', () => ({ ...BASE, direction: mkRevoked([0.6, -0.8, 0]) })],
    ['revoked_event_proxy_cascade', () => mkRevoked({ ...BASE, type: 'cascade' })]];
  for (const [name, make] of fixtures) {
    let optionReads = 0; const options = new Proxy({}, { get() { optionReads++; return undefined; }, ownKeys() { optionReads++; return []; }, getOwnPropertyDescriptor() { optionReads++; return undefined; }, has() { optionReads++; return false; } });
    const before = { ...K._counters }; let res = null, threw = null;
    try { res = K.simulateEvent(make(), options); } catch (e) { threw = String(e); uncaught++; }
    let vres = null; try { vres = K.validateEventInput(make()); } catch (e) { threw = threw || String(e); uncaught++; }
    rows.push({ name, status: res?.status ?? null, validate_code: vres?.code ?? null, error: res?.errors?.[0] ?? threw, physicsCalls: K._counters.physicsRuns - before.physicsRuns, rngCalls: K._counters.rngStreams - before.rngStreams, optionsReads: optionReads, uncaught: !!threw });
  }
  // RC0.7 behaviour on the same fixtures (for the record)
  const rc07 = fixtures.slice(0, 3).map(([name, make]) => { try { return { name, rc07: K7.simulateEvent(make()).status }; } catch (e) { return { name, rc07: 'THREW ' + e.name }; } });
  // legal scale-safe behaviour retained
  const legal = [[MAX, MAX, 0], [5e-324, 0, 0], [1e-308, 1e-308, 0], [3, -4, 0]].map(d => { const v = K.validateEventInput({ ...BASE, direction: d }); const v7 = K7.validateEventInput({ ...BASE, direction: d }); return { d: d.map(String), ok: v.ok, same_as_rc07: JSON.stringify(v) === JSON.stringify(v7) }; });
  R.proxy = { fixtures: rows, rc07_behaviour: rc07, legal_retained: legal };
  save('INPUT_PROXY_SAFETY_TESTS.json', R.proxy);
  const ok = rows.every(r => r.status === 'INVALID_INPUT' && r.validate_code === 'INVALID_INPUT' && r.physicsCalls === 0 && r.rngCalls === 0 && r.optionsReads === 0 && !r.uncaught) && uncaught === 0 && legal.every(l => l.ok && l.same_as_rc07);
  gate('G15_revoked_proxy_safety', ok, { fixtures: rows.map(r => `${r.name}:${r.status} phys=${r.physicsCalls} rng=${r.rngCalls} opt=${r.optionsReads}`), rc07: rc07.map(r => `${r.name}:${r.rc07}`) });
}

/* ============ G16 semantic first-contact (static, all shipped variants) ============ */
{
  const files = ['app/app_template.html', 'dist/icecube_rc071.html', 'dist/icecube_rc071_artifact_body.html', 'dist/offline/index.html'];
  const BAN = ['重建方向', '可信方向', '方向可用', '有徑跡可抓方向', '方向通過可信度檢查', '可靠方向', '真實來向', '真實路徑', 'USABLE', 'FIT_DISPLAYABLE'];
  const REQ = ['真實 IceCube 會用校準的探測器模型與重建方法估計事件；本頁的簡化 LineFit 只畫候選徑跡，可能嚴重失敗，甚至反向。', '方向重建示意', 'LineFit 示意', '候選徑跡', '模擬真值', '頂點與光分布', '顯示 LineFit 示意（可能失敗／反向）', '顯示電荷重心示意',
    'LineFit 是簡化的初步重建，只作示意；可能失敗，甚至反向。內部數值／幾何檢查不證明方向正確。擬合斜率是回歸參數，不是粒子或光子的速度。',
    '利用 DOM 到達時間與位置做簡化 LineFit，估計一條候選徑跡；這個估計可能嚴重失敗，甚至翻轉方向，不能直接當成可信的微中子來向。',
    '這個事件同時有徑跡與簇射。簡化 LineFit 只給一條候選徑跡；簇射主導或命中幾何不利時可能嚴重失敗，甚至反向。',
    '本教學級聯模型的光完全等向；命中不含入射方向資訊，因此不輸出方向重建。可觀察的是示意頂點、拓撲與相對光分布；光量未校準，不能反推真實能量。'];
  const per = files.map(f => { const t = fs.existsSync(ROOT + f) ? fs.readFileSync(ROOT + f, 'utf8') : ''; return { file: f, present: !!t, banned_found: BAN.filter(b => t.includes(b)), required_missing: REQ.filter(r => !t.includes(r)) }; });
  const runtimeFile = ROOT + 'results_frozen/UI_RUNTIME_CHECK.json';
  const runtime = fs.existsSync(ROOT + 'results/UI_RUNTIME_CHECK.json') ? JSON.parse(fs.readFileSync(ROOT + 'results/UI_RUNTIME_CHECK.json')) : (fs.existsSync(runtimeFile) ? JSON.parse(fs.readFileSync(runtimeFile)) : null);
  R.ui_static = { files: per, runtime_check: runtime ? { source: runtime.source, all_pass: runtime.all_pass } : 'not run on this machine (needs Playwright); see tests/ui_runtime_check.mjs' };
  save('UI_SEMANTIC_STATIC.json', R.ui_static);
  gate('G16_semantic_first_contact_static', per.every(p => p.present && !p.banned_found.length && !p.required_missing.length), { files: per.map(p => `${p.file}: banned=${p.banned_found.length} missing=${p.required_missing.length}`), runtime: runtime ? runtime.all_pass : 'not run here' });
}

/* ============ G17 physics identity with RC0.7 (release-gate patch must not change physics) ============ */
{
  const inputs = [];
  for (let i = 0; i < 300; i++) inputs.push(K.sampleEventInput(['through', 'starting', 'cascade'][i % 3], [1, 10, 100, 1000, 10000][i % 5], ['up', 'down', 'any'][Math.floor(i / 3) % 3], 55500000 + i));
  for (const [t, E, seed] of [['starting', 100, 7006668], ['starting', 10, 7003149], ['starting', 100, 40003618], ['cascade', 100, 40005452], ['starting', 1, 16051], ['through', 100, 1492]]) inputs.push(K.sampleEventInput(t, E, 'any', seed));
  const norm = r => { const x = strip(r); if (x.reco.fitStatus === 'FIT_DISPLAYABLE') x.reco.fitStatus = 'FIT_RENDERABLE'; return { x, qa: r.qa, ledger: r.ledger }; };
  let same = 0; const diffs = [];
  for (const inp of inputs) { const a = norm(K.simulateEvent(inp)), b = norm(K7.simulateEvent(inp)); if (rawHash(a) === rawHash(b)) same++; else if (diffs.length < 5) diffs.push(inp); }
  const p02 = K.simulateEvent(K.sampleEventInput('starting', 100, 'any', 7006668));
  R.physics_identity = { events: inputs.length, identical_to_rc07: same, diffs, note: 'Compared: all hits (dom, measured & physical time, charge, noise, clean), ledger, fit status (DISPLAYABLE→RENDERABLE rename mapped), fit direction/speed, vertex estimate and QA values.',
    fixture_40003618: 'UNREPRODUCED: GPT\'s exact EventInput for seed 40003618 (123.197987°) was not supplied. Run `node tests/check_fixture.mjs \'<EventInput JSON>\'` to verify it in seconds.',
    analogue_7006668: { fitStatus: p02.reco.fitStatus, directionStatus: p02.reco.directionStatus, qa: p02.qa } };
  save('PHYSICS_IDENTITY_RC07.json', R.physics_identity);
  gate('G17_physics_identical_to_rc07', same === inputs.length, { events: inputs.length, identical: same });
}

/* ============ G18 exact GPT fixtures (EventInputs from GPT's RC0.7 P0_REGRESSION_RESULTS.json) ============ */
{
  const EX = [
    { id: 'P0-02 exact', expect_err: 123.197986998, expect_clean: 29, input: { seed: 40003618, type: 'starting', energy: 100, vertex: [13.51335848642547, -2054.7249785158783, -349.13105856992416], direction: [0.254969431141881, 0.5841294150450267, -0.7705734330109887] } },
    { id: 'analogue 7006668 (GPT exact input)', expect_err: 98.009732, input: { seed: 7006668, type: 'starting', vertex: [363.5447376979919, -2068.200532742776, 80.42098546382503], direction: [0.45510548053211586, -0.08193538570776582, 0.8866597961780783], energy: 100 } },
    { id: 'analogue 7003149 (GPT exact input)', expect_err: 122.233247, input: { seed: 7003149, type: 'starting', vertex: [62.786472059811075, -2089.6347515285015, -109.79675898151777], direction: [-0.1344149154598042, 0.21693254308775067, -0.9668882573759052], energy: 10 } },
  ];
  const rows = EX.map(e => { const r = K.simulateEvent(e.input); const r6 = K6.simulateEvent(e.input); const r7 = K7.simulateEvent(e.input);
    return { id: e.id, input: e.input, clean: r.clean.length, fitDirection: r.reco.fitDirection, fitStatus: r.reco.fitStatus, directionStatus: r.reco.directionStatus, disclaimers: r.reco.disclaimers, qa: r.qa,
      expected_err_deg: e.expect_err, err_matches: Math.abs(r.qa.angularError_deg - e.expect_err) < 1e-5, clean_matches: e.expect_clean ? r.clean.length === e.expect_clean : null,
      rc06_status: r6.reco.status, rc06_err: K6.qaAngularError(r6.reco.dir, e.input.direction), rc07_err: r7.qa.angularError_deg, rc07_fitStatus: r7.reco.fitStatus }; });
  R.exact_fixtures = rows; save('EXACT_GPT_FIXTURES.json', rows);
  const ok = rows.every(x => x.err_matches && x.clean_matches !== false && x.fitStatus === 'FIT_RENDERABLE' && x.directionStatus === 'ILLUSTRATIVE_LINEFIT' && x.qa.hemisphereFlip === (x.qa.angularError_deg > 90) && x.disclaimers.includes(K.DISCLAIMERS.noValidation));
  gate('G18_exact_GPT_fixtures_still_wrong_but_illustrative', ok, { rows: rows.map(x => `${x.id}: err=${x.qa.angularError_deg.toFixed(6)}° clean=${x.clean} ${x.fitStatus}/${x.directionStatus} rc06=${x.rc06_status}`) });
}

R.gates = GATES; R.all_pass = Object.values(GATES).every(g => g.pass !== false); R.skipped = Object.entries(GATES).filter(([, g]) => g.skipped).map(([k]) => k); R.runtime_s = (Date.now() - T0) / 1000;
save('REGRESSION_RESULTS.json', R);
console.log('\nALL GATES PASS:', R.all_pass, `(${R.runtime_s.toFixed(0)} s)`);
process.exit(R.all_pass ? 0 : 1);
