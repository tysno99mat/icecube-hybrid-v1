# Claude IceCube RC0.7.1 Candidate

**`CLAUDE RC0.7.1 — READY FOR TWO-BLOCKER GPT GATE CHECK`**

只修 B-INPUT-01 與 B-UI-01。物理行為與 RC0.7 逐位元相同（G17）。GPT 的精確 fixture seed 40003618 仍然得到 123.197987°，並標為示意（G18）。沒有建立 Hybrid，沒有部署。

```
sh REPRODUCE.sh          # 離線執行：integrity → SHA256 → 全部閘門 → 與 results_frozen 比對
node tests/ui_runtime_check.mjs <playwright/index.mjs>   # 選用：執行期文案檢查（需要 Playwright）
node tests/check_fixture.mjs '<EventInput JSON>'         # 檢查任一精確輸入
```

| 交付 | 檔案 |
|---|---|
| Claude_IceCube_RC0.7.1_Candidate.zip | 本壓縮檔 |
| RC0.7.1_CHANGELOG.md | `docs/` |
| INPUT_PROXY_SAFETY_TESTS.json | 根目錄與 `results_frozen/` |
| UI_SEMANTIC_PATCH.md | `docs/` |
| REGRESSION_RESULTS.json | 根目錄與 `results_frozen/` |
| EXACT_GPT_FIXTURES.json（G18） | 根目錄與 `results_frozen/` |
| SHA256 manifest | `SHA256SUMS.txt` |
| one-command offline replay | `REPRODUCE.sh` |

RC0.7 的文件原樣保留在 `docs/rc07/`，作為這次修補的基準。
